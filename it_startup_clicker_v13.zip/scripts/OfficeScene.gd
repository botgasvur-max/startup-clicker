extends Control

@onready var module_list = %ModuleList

var modules = [
	{"id": "coffee_machine", "name": "Кофемашина", "cost": 2000, "desc": "Больше энергии сотрудникам (+10% пассивный доход)"},
	{"id": "bean_bags", "name": "Кресла-мешки", "cost": 1500, "desc": "Улучшает настроение команды"},
	{"id": "server_rack", "name": "Серверная стойка", "cost": 10000, "desc": "Дополнительный пассивный доход (+100 L-C/сек)"}
]

func _ready():
	ThemeManager.apply_glass_theme(self)
	_update_list()

func _update_list():
	for child in module_list.get_children():
		child.queue_free()
	
	# Office Stats Bar
	var stats = PanelContainer.new()
	var s_hbox = HBoxContainer.new()
	stats.add_child(s_hbox)
	var l_title = Label.new()
	l_title.text = "ИНТЕРЬЕР ОФИСА: " + GameManager.STAGE_DATA[GameManager.current_stage].name
	l_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s_hbox.add_child(l_title)
	module_list.add_child(stats)

	# Visual Slot Layout (Simplified Grid)
	var grid = GridContainer.new()
	grid.columns = 5
	grid.custom_minimum_size = Vector2(0, 200)
	module_list.add_child(grid)
	
	# Static Decorations / Furniture Slots
	var furniture = [
		{"id": "coffee_machine", "name": "Кофемашина", "icon": "☕"},
		{"id": "bean_bags", "name": "Кресло-мешок", "icon": "🛋️"}
	]
	
	for f in furniture:
		var slot = Button.new()
		var active = GameManager.office_modules[f.id]
		slot.text = f.icon if active else "➕"
		slot.tooltip_text = f.name if active else "Установить " + f.name
		slot.custom_minimum_size = Vector2(60, 60)
		slot.disabled = active
		slot.pressed.connect(_buy_module.bind(f.id, 2000))
		grid.add_child(slot)

	# Server Status / Restart logic
	if not GameManager.servers_online:
		var alert = PanelContainer.new()
		var a_style = StyleBoxFlat.new()
		a_style.bg_color = Color(0.8, 0, 0, 0.4)
		alert.add_theme_stylebox_override("panel", a_style)
		
		var v = VBoxContainer.new()
		alert.add_child(v)
		var l = Label.new()
		l.text = "!!! СЕРВЕРЫ ОТКЛЮЧЕНЫ !!!\nТребуется ручной перезапуск систем."
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		v.add_child(l)
		
		var rb = Button.new()
		rb.text = "ПЕРЕЗАПУСТИТЬ ВСЕ СИСТЕМЫ"
		rb.pressed.connect(_on_restart_pressed)
		v.add_child(rb)
		module_list.add_child(alert)
		return # Hide other things during outage

	var cur_stage_data = GameManager.STAGE_DATA[GameManager.current_stage]
	var max_s = cur_stage_data.max_servers
	var current_s = GameManager.office_modules.server_slots.size()
	
	var progress_panel = PanelContainer.new()
	var p_vbox = VBoxContainer.new()
	progress_panel.add_child(p_vbox)
	
	var p_label = Label.new()
	p_label.text = "ЗАПОЛНЕНИЕ СЕРВЕРНОЙ: %d / %d" % [current_s, max_s]
	p_vbox.add_child(p_label)
	
	var p_bar = ProgressBar.new()
	p_bar.max_value = max_s
	p_bar.value = current_s
	p_vbox.add_child(p_bar)
	
	module_list.add_child(progress_panel)

	# Install New Server Button
	if current_s < max_s:
		var install_panel = PanelContainer.new()
		var install_btn = Button.new()
		var cost = 1000 * (GameManager.current_stage + 1)
		install_btn.text = "УСТАНОВИТЬ НОВЫЙ СЕРВЕР (Слот %d) - %d L-C" % [current_s + 1, cost]
		install_btn.pressed.connect(_install_server.bind(cost))
		install_panel.add_child(install_btn)
		module_list.add_child(install_panel)

	# List Servers (Limited for performance)
	var display_count = min(current_s, 50) # Only show first 50 to avoid lag
	for i in range(display_count):
		var level = GameManager.office_modules.server_slots[i]
		var s_panel = PanelContainer.new()
		var s_hbox = HBoxContainer.new()
		s_panel.add_child(s_hbox)
		
		var s_info = Label.new()
		var icon = "🖥️" if level < 3 else ("💾" if level < 7 else "⚡")
		s_info.text = "%s СЕРВЕР #%d [УРОВЕНЬ %d]" % [icon, i+1, level]
		s_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		s_hbox.add_child(s_info)
		
		if level < 10:
			var u_btn = Button.new()
			var u_cost = 500 * level
			u_btn.text = "УЛУЧШИТЬ (%d L-C)" % u_cost
			u_btn.pressed.connect(_upgrade_server_slot.bind(i, u_cost))
			s_hbox.add_child(u_btn)
			
		module_list.add_child(s_panel)
	
	if current_s > 50:
		var more_lbl = Label.new()
		more_lbl.text = "... и еще %d серверов работают в фоне" % [current_s - 50]
		more_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		module_list.add_child(more_lbl)

	# Home Server Tier Entry
	var s_panel = PanelContainer.new()
	var s_hbox = HBoxContainer.new()
	s_panel.add_child(s_hbox)
	var s_tier = GameManager.office_modules.home_server_tier
	var s_info = Label.new()
	s_info.text = "Домашний Сервер (Уровень %d)\nПассивный доход: %.f L-C" % [s_tier, s_tier * 25.0 * (1.0 + s_tier * 0.5)]
	s_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s_hbox.add_child(s_info)
	
	if s_tier < 5:
		var s_btn = Button.new()
		var s_cost = 500 * (s_tier + 1)
		s_btn.text = "Улучшить (%d L-C)" % s_cost
		s_btn.pressed.connect(_upgrade_home_server.bind(s_cost))
		s_hbox.add_child(s_btn)
	module_list.add_child(s_panel)

	for mod in modules:
		var panel = PanelContainer.new()
		var hbox = HBoxContainer.new()
		panel.add_child(hbox)
		
		var val = GameManager.office_modules[mod.id]
		var status = ""
		if typeof(val) == TYPE_BOOL:
			status = "[КУПЛЕНО]" if val else ""
		else:
			status = "[Уровень: " + str(val) + "]"
			
		var info = Label.new()
		info.text = "%s %s\n%s" % [status, mod.name, mod.desc]
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(info)
		
		var buy_btn = Button.new()
		buy_btn.text = "Купить/Улучшить (%d L-C)" % mod.cost
		if typeof(val) == TYPE_BOOL and val:
			buy_btn.disabled = true
		buy_btn.pressed.connect(_buy_module.bind(mod.id, mod.cost))
		hbox.add_child(buy_btn)
		
		module_list.add_child(panel)

func _upgrade_home_server(cost):
	if GameManager.spend_money(cost):
		GameManager.office_modules.home_server_tier += 1
		GameManager.calculate_multipliers()
		VisualEffectsManager.glitch_effect(self)
		_update_list()

func _install_server(cost):
	if GameManager.spend_money(cost):
		GameManager.office_modules.server_slots.append(1)
		GameManager.calculate_multipliers()
		_update_list()

func _upgrade_server_slot(index, cost):
	if GameManager.spend_money(cost):
		GameManager.office_modules.server_slots[index] += 1
		GameManager.calculate_multipliers()
		_update_list()

func _on_restart_pressed():
	GameManager.restart_servers()
	_update_list()

func _buy_module(id, cost):
	if GameManager.spend_money(cost):
		var val = GameManager.office_modules[id]
		if typeof(val) == TYPE_BOOL:
			GameManager.office_modules[id] = true
		else:
			GameManager.office_modules[id] += 1
		
		GameManager.calculate_multipliers()
		_update_list()
