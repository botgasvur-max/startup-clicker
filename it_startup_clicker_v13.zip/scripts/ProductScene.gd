extends Control

@onready var project_list = %ProjectList
@onready var active_list = %ActiveList
@onready var progress_bar = %ProgressBar
@onready var project_label = %ProjectLabel

var project_templates = {
	"simple_app": {"name": "Простое приложение", "cost": 1000, "work_needed": 100, "base_revenue": 50, "type": "app"},
	"mobile_game": {"name": "Мобильная игра", "cost": 5000, "work_needed": 500, "base_revenue": 300, "type": "game"},
	"social_network": {"name": "Соцсеть", "cost": 50000, "work_needed": 5000, "base_revenue": 5000, "type": "social"},
	"os": {"name": "Операционная система", "cost": 500000, "work_needed": 50000, "base_revenue": 60000, "type": "os"},
	"cloud_service": {"name": "Облачный сервис", "cost": 1000000, "work_needed": 100000, "base_revenue": 150000, "type": "cloud"},
	"crypto_exchange": {"name": "Крипто-биржа", "cost": 5000000, "work_needed": 250000, "base_revenue": 200000, "type": "crypto"}
}

func _ready():
	ThemeManager.apply_glass_theme(self)
	_update_lists()
	# Revenue timer
	var timer = Timer.new()
	timer.wait_time = 10.0
	timer.autostart = true
	timer.timeout.connect(_generate_revenue)
	add_child(timer)

func _update_lists():
	# Update Templates
	for child in project_list.get_children(): child.queue_free()
	for id in project_templates.keys():
		var t = project_templates[id]
		var btn = Button.new()
		btn.text = "%s (Цена: %d L-C)" % [t.name, t.cost]
		btn.pressed.connect(_start_project.bind(id))
		project_list.add_child(btn)
		
	# Update Active Products
	for child in active_list.get_children(): child.queue_free()
	for i in range(GameManager.active_products.size()):
		var p = GameManager.active_products[i]
		var hbox = HBoxContainer.new()
		
		var lbl = Label.new()
		lbl.text = "%s (%s)\nЮзеров: %d | Доход: %d | Баги: %d" % [p.name, p.type, p.users, p.revenue, p.bugs]
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(lbl)
		
		if p.bugs > 0:
			var patch_btn = Button.new()
			patch_btn.text = "Исправить (100 L-C)"
			patch_btn.pressed.connect(_patch_bugs.bind(i))
			hbox.add_child(patch_btn)
			
		active_list.add_child(hbox)

func _patch_bugs(index):
	if GameManager.spend_money(100):
		GameManager.active_products[index].bugs = max(0, GameManager.active_products[index].bugs - 1)
		_update_lists()

func _start_project(id):
	var t = project_templates[id]
	
	if GameManager.mentor_data.skills.instant_release.level > 0 and randf() < 0.2:
		if GameManager.spend_money(t.cost):
			GameManager.current_project_type = id
			_finish_project()
			GameManager.news_updated.emit("НАСТАВНИК: Мгновенный релиз завершен!")
			return

	if GameManager.spend_money(t.cost):
		GameManager.current_project_type = id
		GameManager.project_progress = 0
		project_label.text = "Разработка: " + t.name
		_update_ui()

func _process(_delta):
	if GameManager.current_project_type != "":
		progress_bar.max_value = project_templates[GameManager.current_project_type].work_needed
		progress_bar.value = GameManager.project_progress
		
		if GameManager.project_progress >= progress_bar.max_value:
			_finish_project()

func _finish_project():
	var t = project_templates[GameManager.current_project_type]
	var new_product = {
		"name": t.name + " #" + str(GameManager.active_products.size() + 1),
		"type": t.name,
		"template_id": GameManager.current_project_type,
		"users": randi_range(100, 1000),
		"revenue": t.base_revenue,
		"hype": 50.0,
		"bugs": 0
	}
	GameManager.active_products.append(new_product)
	GameManager.current_project_type = ""
	GameManager.project_progress = 0
	project_label.text = "Нет активного проекта"
	_update_lists()
	_update_ui()

func _generate_revenue():
	var total = 0
	for p in GameManager.active_products:
		# Revenue is affected by Hype and Fans
		var template = project_templates.get(p.get("template_id", "simple_app"), {})
		var type = template.get("type", "app")
		
		var type_mult = 1.0
		if type == "crypto":
			type_mult = GameManager.crypto_market_multiplier
		elif type == "cloud" and not GameManager.servers_online:
			type_mult = 0.1 # Cloud services fail during outages

		var current_rev = p.revenue * (GameManager.hype) * type_mult
		total += current_rev
		
		# Hype slowly decays
		GameManager.hype = max(1.0, GameManager.hype - 0.05)
		
		# Products gain some users naturally
		p.users += randi_range(1, 10)
		
		# Fan interaction: bugs hurt fans, polish gains them
		if p.bugs > 5:
			GameManager.fans = max(0, GameManager.fans - 5)
		elif p.bugs == 0:
			GameManager.fans += 1
		
	GameManager.add_money(total)

func _on_marketing_pressed():
	if GameManager.spend_money(2000):
		GameManager.hype += 0.5
		_update_ui()

func _update_ui():
	pass # Add more UI updates if needed
