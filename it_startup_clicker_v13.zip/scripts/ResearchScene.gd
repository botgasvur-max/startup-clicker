extends Control

@onready var tech_list = %TechList

var techs = [
	{"id": "fast_typing", "name": "Скоропечатание", "cost": 1000, "desc": "Увеличивает доход от кликов на 20%"},
	{"id": "ai_copilot", "name": "AI Копилот", "cost": 5000, "desc": "Автоматическая помощь в коде (х1.2 ко всему доходу)"},
	{"id": "cloud_computing", "name": "Облачные вычисления", "cost": 20000, "desc": "Удваивает пассивный доход от серверов"},
	{"id": "cybersecurity", "name": "Кибербезопасность", "cost": 15000, "desc": "Снижает шанс хакерских атак на 50%"}
]

func _ready():
	ThemeManager.apply_glass_theme(self)
	_update_tech_list()
	GameManager.research_points_changed.connect(_on_rp_changed)

func _on_rp_changed(_val):
	_update_tech_list()

func _update_tech_list():
	for child in tech_list.get_children():
		child.queue_free()
		
	var rp_panel = PanelContainer.new()
	var rp_lbl = Label.new()
	rp_lbl.text = "ОЧКИ ИССЛЕДОВАНИЙ (RP): %.1f" % GameManager.research_points
	rp_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rp_panel.add_child(rp_lbl)
	tech_list.add_child(rp_panel)

	# Regular Techs
	var t_header = Label.new()
	t_header.text = "\n--- ТЕХНОЛОГИИ (L-Coins) ---"
	tech_list.add_child(t_header)

	for tech in techs:
		var panel = PanelContainer.new()
		var hbox = HBoxContainer.new()
		panel.add_child(hbox)
		
		var info = Label.new()
		var status = "[ИЗУЧЕНО]" if GameManager.tech_tree[tech.id] else "[НЕ ИЗУЧЕНО]"
		info.text = "%s %s\n%s" % [status, tech.name, tech.desc]
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(info)
		
		var buy_btn = Button.new()
		buy_btn.text = "Изучить (%d L-C)" % tech.cost
		buy_btn.disabled = GameManager.tech_tree[tech.id]
		buy_btn.pressed.connect(_buy_tech.bind(tech.id, tech.cost))
		hbox.add_child(buy_btn)
		
		tech_list.add_child(panel)

	# RP Specialized Boosts
	var r_header = Label.new()
	r_header.text = "\n--- УСКОРЕНИЕ (RP) ---"
	tech_list.add_child(r_header)
	
	var boosts = [
		{"id": "python_basics", "name": "Основы Python", "rp": 10},
		{"id": "cpp_hardcore", "name": "C++ Hardcore", "rp": 100},
		{"id": "server_admin", "name": "Администрирование", "rp": 50}
	]
	
	for b in boosts:
		var skill = GameManager.find_skill(b.id)
		if skill and skill.level < skill.max:
			var panel = PanelContainer.new()
			var hbox = HBoxContainer.new()
			panel.add_child(hbox)
			
			var info = Label.new()
			info.text = "Мгновенно изучить: %s" % b.name
			info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			hbox.add_child(info)
			
			var rp_btn = Button.new()
			rp_btn.text = "Изучить (%d RP)" % b.rp
			rp_btn.pressed.connect(_buy_with_rp.bind(b.id, b.rp))
			hbox.add_child(rp_btn)
			tech_list.add_child(panel)

	# Mentor Upgrading
	var m_header = Label.new()
	m_header.text = "\n--- НАСТАВНИК / CTO (RP) ---"
	tech_list.add_child(m_header)
	
	for i in range(GameManager.employees.size()):
		var emp = GameManager.employees[i]
		if emp.get("is_mentor", false):
			var panel = PanelContainer.new()
			var hbox = HBoxContainer.new()
			panel.add_child(hbox)
			
			var info = Label.new()
			info.text = "Улучшить навыки наставничества (+5% RP/Продуктивность)"
			info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			hbox.add_child(info)
			
			var up_btn = Button.new()
			var rp_cost = 50 * emp.level
			up_btn.text = "УЛУЧШИТЬ (%d RP)" % rp_cost
			up_btn.pressed.connect(_upgrade_mentor.bind(i, rp_cost))
			hbox.add_child(up_btn)
			tech_list.add_child(panel)

	# Employee Upgrading
	var e_header = Label.new()
	e_header.text = "\n--- ОБУЧЕНИЕ СОТРУДНИКОВ (RP) ---"
	tech_list.add_child(e_header)
	
	for i in range(GameManager.employees.size()):
		var emp = GameManager.employees[i]
		var panel = PanelContainer.new()
		var hbox = HBoxContainer.new()
		panel.add_child(hbox)
		
		var info = Label.new()
		info.text = "%s (%s) | Скилл: %d" % [emp.name, emp.role, emp.skill]
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(info)
		
		var train_btn = Button.new()
		var rp_cost = 20
		train_btn.text = "+10 Скилл (%d RP)" % rp_cost
		train_btn.pressed.connect(_train_with_rp.bind(i, rp_cost))
		hbox.add_child(train_btn)
		tech_list.add_child(panel)

func _buy_tech(id, cost):
	if GameManager.spend_money(cost):
		GameManager.tech_tree[id] = true
		GameManager.calculate_multipliers()
		_update_tech_list()

func _buy_with_rp(skill_id, rp):
	if GameManager.spend_research_points(rp):
		var skill = GameManager.find_skill(skill_id)
		skill.level = skill.max
		GameManager.calculate_multipliers()
		_update_tech_list()

func _train_with_rp(index, rp):
	if GameManager.spend_research_points(rp):
		GameManager.employees[index].skill += 10
		GameManager.calculate_multipliers()
		_update_tech_list()

func _upgrade_mentor(index, rp):
	if GameManager.spend_research_points(rp):
		var emp = GameManager.employees[index]
		emp.level += 1
		emp.bonus_productivity += 0.05
		GameManager.calculate_multipliers()
		_update_tech_list()
