extends Node

func apply_glass_theme(node: Node):
	if node is PanelContainer:
		var style = StyleBoxFlat.new()
		style.bg_color = Color(0.1, 0.1, 0.1, 0.7) # Semi-transparent
		style.corner_radius_top_left = 15
		style.corner_radius_top_right = 15
		style.corner_radius_bottom_left = 15
		style.corner_radius_bottom_right = 15
		style.border_width_left = 1
		style.border_width_top = 1
		style.border_width_right = 1
		style.border_width_bottom = 1
		style.border_color = Color(1, 1, 1, 0.2)
		node.add_theme_stylebox_override("panel", style)
	
	if node is Button:
		var normal = StyleBoxFlat.new()
		normal.bg_color = Color(0.2, 0.4, 0.8, 0.6)
		normal.corner_radius_top_left = 8
		normal.corner_radius_top_right = 8
		normal.corner_radius_bottom_left = 8
		normal.corner_radius_bottom_right = 8
		node.add_theme_stylebox_override("normal", normal)
		
		var hover = normal.duplicate()
		hover.bg_color = Color(0.3, 0.5, 1.0, 0.8)
		node.add_theme_stylebox_override("hover", hover)

	for child in node.get_children():
		apply_glass_theme(child)

func add_procedural_background(node: Control):
	var bg = ColorRect.new()
	bg.name = "ProceduralBG"
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.show_behind_parent = true
	
	# Create a gradient effect
	var gradient = Gradient.new()
	gradient.add_point(0.0, Color(0.05, 0.05, 0.1))
	gradient.add_point(1.0, Color(0.1, 0.15, 0.2))
	
	var texture = GradientTexture2D.new()
	texture.gradient = gradient
	texture.fill_from = Vector2(0.5, 0)
	texture.fill_to = Vector2(0.5, 1)
	
	# Since ColorRect doesn't take texture, we use a TextureRect
	var tr = TextureRect.new()
	tr.texture = texture
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	tr.show_behind_parent = true
	node.add_child(tr)
	node.move_child(tr, 0)
