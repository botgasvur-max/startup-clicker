extends Control

@onready var part_list = %PartList

var catalog = {
	"cpu": [
		{"name": "Intel i3-12100", "cost": 500, "power": 1.5, "tdp": 60, "specs": "4 Cores | 3.3 GHz"},
		{"name": "Ryzen 7 7800X3D", "cost": 2500, "power": 4.0, "tdp": 120, "specs": "8 Cores | 4.2 GHz"},
		{"name": "Threadripper 7995WX", "cost": 15000, "power": 15.0, "tdp": 350, "specs": "96 Cores | 2.5 GHz"}
	],
	"gpu": [
		{"name": "GTX 1650", "cost": 800, "power": 1.5, "tdp": 75, "specs": "4GB VRAM"},
		{"name": "RTX 4090", "cost": 5000, "power": 8.0, "tdp": 450, "specs": "24GB VRAM"},
		{"name": "H100 NVL", "cost": 80000, "power": 50.0, "tdp": 700, "specs": "80GB HBM3"}
	],
	"ram": [
		{"name": "16GB DDR4-3200", "cost": 300, "power": 1.2, "specs": "CL16"},
		{"name": "64GB DDR5-6000", "cost": 1500, "power": 3.0, "specs": "CL30"},
		{"name": "256GB DDR5-ECC", "cost": 12000, "power": 8.0, "specs": "Registered"}
	],
	"cooling": [
		{"name": "Stock Cooler", "cost": 0, "capacity": 65, "specs": "Air"},
		{"name": "Noctua NH-D15", "cost": 1500, "capacity": 250, "specs": "Dual Tower Air"},
		{"name": "Custom Loop", "cost": 10000, "capacity": 1000, "specs": "Liquid Cooling"}
	],
	"psu": [
		{"name": "Bronze 500W", "cost": 400, "wattage": 500, "specs": "80 Plus"},
		{"name": "Gold 850W", "cost": 1200, "wattage": 850, "specs": "Fully Modular"},
		{"name": "Titanium 1600W", "cost": 5000, "wattage": 1600, "specs": "Digital Power"}
	]
}

func _ready():
	ThemeManager.apply_glass_theme(self)
	_update_catalog()

func _update_catalog():
	for child in part_list.get_children():
		child.queue_free()
		
	# Summary info at top
	_add_pc_summary()

	for type in catalog.keys():
		var label = Label.new()
		label.text = "\n--- " + type.to_upper() + " ---"
		label.modulate = Color.CYAN
		part_list.add_child(label)
		
		for item in catalog[type]:
			var panel = PanelContainer.new()
			var hbox = HBoxContainer.new()
			panel.add_child(hbox)
			
			var info = Label.new()
			var current = " [УСТАНОВЛЕНО]" if GameManager.pc_parts.get(type, {}).get("name") == item.name else ""
			var bonus_val = item.get("power", item.get("capacity", item.get("wattage", 0)))
			var bonus_text = "Мощность: x%.1f" % bonus_val if item.has("power") else ("Охлаждение: %dW" % bonus_val if item.has("capacity") else "Питание: %dW" % bonus_val)
			
			info.text = "%s %s\n%s | %s" % [current, item.name, item.specs, bonus_text]
			info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			hbox.add_child(info)
			
			var buy_btn = Button.new()
			buy_btn.text = "Купить (%d L-C)" % item.cost
			buy_btn.disabled = GameManager.pc_parts.get(type, {}).get("name") == item.name
			buy_btn.pressed.connect(_buy_part.bind(type, item))
			hbox.add_child(buy_btn)
			
			part_list.add_child(panel)

func _add_pc_summary():
	var panel = PanelContainer.new()
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.2, 0.2, 0.2, 0.5)
	panel.add_theme_stylebox_override("panel", style)
	
	var vbox = VBoxContainer.new()
	panel.add_child(vbox)
	
	var total_tdp = GameManager.pc_parts.cpu.tdp + GameManager.pc_parts.gpu.tdp
	var cooling = GameManager.pc_parts.cooling.capacity
	var psu = GameManager.pc_parts.psu.wattage
	
	var tdp_lbl = Label.new()
	tdp_lbl.text = "ТЕПЛОВЫДЕЛЕНИЕ: %d / %d W" % [total_tdp, cooling]
	tdp_lbl.modulate = Color.GREEN if cooling >= total_tdp else Color.RED
	vbox.add_child(tdp_lbl)
	
	var psu_lbl = Label.new()
	psu_lbl.text = "ЭНЕРГОПОТРЕБЛЕНИЕ: %d / %d W" % [total_tdp + 50, psu]
	psu_lbl.modulate = Color.GREEN if psu >= (total_tdp + 50) else Color.RED
	vbox.add_child(psu_lbl)
	
	if cooling < total_tdp or psu < (total_tdp + 50):
		var warn = Label.new()
		warn.text = "ВНИМАНИЕ: СИСТЕМА НЕСТАБИЛЬНА. ДОХОД СНИЖЕН."
		warn.modulate = Color.YELLOW
		vbox.add_child(warn)
		GameManager.global_modifier *= 0.5 # Penalty for bad build
		
	part_list.add_child(panel)

func _buy_part(type, data):
	if GameManager.spend_money(data.cost):
		var new_data = {"name": data.name}
		for key in data.keys():
			if key != "cost" and key != "specs":
				new_data[key] = data[key]
		
		GameManager.pc_parts[type] = new_data
		GameManager.calculate_multipliers()
		_update_catalog()
