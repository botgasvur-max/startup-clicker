extends Control

@onready var stock_list = %StockList
@onready var balance_label = %BalanceLabel

func _ready():
	ThemeManager.apply_glass_theme(self)
	EventManager.stock_prices_updated.connect(_update_stocks)
	_update_ui()

func _update_ui():
	_update_stocks()
	_update_marketing()

func _update_stocks():
	for child in stock_list.get_children():
		child.queue_free()
	
	balance_label.text = "Ваш баланс: " + str(floor(GameManager.l_coins)) + " L-C"
	
	var s_header = Label.new()
	s_header.text = "--- ФОНДОВЫЙ РЫНОК ---"
	stock_list.add_child(s_header)

	for s_name in GameManager.stocks.keys():
		var stock = GameManager.stocks[s_name]
		var hbox = HBoxContainer.new()
		
		var name_lbl = Label.new()
		name_lbl.text = s_name
		name_lbl.custom_minimum_size.x = 100
		hbox.add_child(name_lbl)
		
		var price_lbl = Label.new()
		price_lbl.text = str(snapped(stock.price, 0.01)) + " L-C"
		price_lbl.custom_minimum_size.x = 100
		hbox.add_child(price_lbl)
		
		var owned_lbl = Label.new()
		owned_lbl.text = "Владеете: " + str(stock.owned)
		owned_lbl.custom_minimum_size.x = 120
		hbox.add_child(owned_lbl)
		
		var buy_btn = Button.new()
		buy_btn.text = "Купить"
		buy_btn.pressed.connect(_buy_stock.bind(s_name))
		hbox.add_child(buy_btn)
		
		var sell_btn = Button.new()
		sell_btn.text = "Продать"
		sell_btn.pressed.connect(_sell_stock.bind(s_name))
		hbox.add_child(sell_btn)
		
		stock_list.add_child(hbox)
	
	_update_marketing()

func _update_marketing():
	var m_header = Label.new()
	m_header.text = "\n--- РЕКЛАМНЫЕ КАМПАНИИ ---"
	stock_list.add_child(m_header)
	
	var fan_lbl = Label.new()
	fan_lbl.text = "Фанаты: %d" % GameManager.fans
	fan_lbl.modulate = Color.CYAN
	stock_list.add_child(fan_lbl)

	var campaigns = [
		{"id": "social_media", "name": "Соцсети", "cost": 5000, "duration": 12, "desc": "+20% доход, приток фанатов"},
		{"id": "ads", "name": "Объявления", "cost": 1000, "duration": 6, "desc": "+10% доход"},
		{"id": "tv", "name": "ТВ-Реклама", "cost": 50000, "duration": 24, "desc": "+50% доход, огромный хайп"}
	]
	
	for c in campaigns:
		var panel = PanelContainer.new()
		var hbox = HBoxContainer.new()
		panel.add_child(hbox)
		
		var info = Label.new()
		var active_ticks = GameManager.active_marketing.get(c.id, 0)
		var status = "[АКТИВНО: %d]" % active_ticks if active_ticks > 0 else ""
		info.text = "%s %s (%d L-C)\n%s" % [status, c.name, c.cost, c.desc]
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(info)
		
		var buy_btn = Button.new()
		buy_btn.text = "Запустить"
		buy_btn.pressed.connect(_buy_marketing.bind(c.id, c.cost, c.duration))
		hbox.add_child(buy_btn)
		
		stock_list.add_child(panel)

func _buy_marketing(id, cost, duration):
	if GameManager.start_marketing(id, cost, duration):
		_update_ui()

func _buy_stock(s_name):
	var price = GameManager.stocks[s_name].price
	if GameManager.spend_money(price):
		GameManager.stocks[s_name].owned += 1
		_update_stocks()

func _sell_stock(s_name):
	if GameManager.stocks[s_name].owned > 0:
		var price = GameManager.stocks[s_name].price
		GameManager.stocks[s_name].owned -= 1
		GameManager.add_money(price)
		_update_stocks()
