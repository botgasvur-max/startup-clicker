extends Control

@onready var skill_list = VBoxContainer.new()

func _ready():
	ThemeManager.apply_glass_theme(self)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(scroll)
	scroll.add_child(skill_list)
	_update_skills()

func _update_skills():
	for child in skill_list.get_children(): child.queue_free()
	
	# Mentor Ultimate Skills Section
	var m_title = Label.new()
	m_title.text = "--- УЛЬТИМАТИВНЫЕ НАВЫКИ CTO ---"
	m_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	m_title.modulate = Color.GOLD
	skill_list.add_child(m_title)
	
	for s_id in GameManager.mentor_data.skills.keys():
		var skill = GameManager.mentor_data.skills[s_id]
		var panel = PanelContainer.new()
		var hbox = HBoxContainer.new()
		panel.add_child(hbox)
		
		var info = Label.new()
		var status = "[АКТИВНО]" if skill.level > 0 else "[ЗАБЛОКИРОВАНО]"
		info.text = "%s: %s\n%s" % [status, skill.desc, "Требуется 500 Очков Исследований"]
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(info)
		
		if skill.level == 0:
			var buy_btn = Button.new()
			buy_btn.text = "Разблокировать"
			buy_btn.pressed.connect(_on_mentor_skill_pressed.bind(s_id))
			hbox.add_child(buy_btn)
		
		skill_list.add_child(panel)

	for category in GameManager.skill_tree.keys():
		var cat_lbl = Label.new()
		cat_lbl.text = "--- " + category.to_upper() + " ---"
		cat_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		cat_lbl.modulate = Color.CYAN
		skill_list.add_child(cat_lbl)
		
		var skills = GameManager.skill_tree[category]
		for id in skills.keys():
			var s = skills[id]
			var panel = PanelContainer.new()
			var hbox = HBoxContainer.new()
			panel.add_child(hbox)
			
			var info = Label.new()
			var current_cost = s.cost * (s.level + 1)
			var req_text = ""
			if s.requires.size() > 0:
				req_text = "\nТребует: " + str(s.requires).replace("[", "").replace("]", "")
				
			info.text = "%s (Ур. %d/%d)%s\n%s" % [s.name, s.level, s.max, req_text, s.desc]
			info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			hbox.add_child(info)
			
			if s.level < s.max:
				var buy_btn = Button.new()
				buy_btn.text = "Изучить (%d L-C)" % current_cost
				
				# Check if requirements met to visually disable
				var can_buy = true
				for req in s.requires:
					var rs = GameManager.find_skill(req)
					if rs == null or rs.level < rs.max:
						can_buy = false
						break
				
				if not can_buy:
					buy_btn.disabled = true
					buy_btn.modulate = Color(0.5, 0.5, 0.5)
				
				buy_btn.pressed.connect(_on_skill_pressed.bind(id))
				hbox.add_child(buy_btn)
			else:
				var max_lbl = Label.new()
				max_lbl.text = "МАКСИМУМ"
				max_lbl.modulate = Color.GOLD
				hbox.add_child(max_lbl)
				
			skill_list.add_child(panel)

func _on_mentor_skill_pressed(id):
	if GameManager.spend_research_points(500):
		GameManager.mentor_data.skills[id].level = 1
		_update_skills()
		AudioManager.play_sound("upgrade")

func _on_skill_pressed(id):
	if GameManager.buy_skill(id):
		_update_skills()
		AudioManager.play_sound("upgrade")
