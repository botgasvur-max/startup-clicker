extends Node

func spawn_sparks(pos: Vector2, parent: Node):
	for i in range(5):
		var spark = ColorRect.new()
		spark.size = Vector2(2, 2)
		spark.color = Color.YELLOW
		spark.position = pos
		parent.add_child(spark)
		
		var angle = randf() * TAU
		var distance = randf_range(20, 50)
		var dest = pos + Vector2(cos(angle), sin(angle)) * distance
		
		var tween = parent.create_tween()
		tween.set_parallel(true)
		tween.tween_property(spark, "position", dest, 0.3).set_trans(Tween.TRANS_QUAD).set_ease(Tween.TRANS_OUT)
		tween.tween_property(spark, "modulate:a", 0.0, 0.3)
		tween.tween_property(spark, "scale", Vector2.ZERO, 0.3)
		tween.finished.connect(spark.queue_free)

func screen_shake(node: Node):
	var original_pos = node.position
	var tween = node.create_tween()
	for i in range(10):
		var offset = Vector2(randf_range(-5, 5), randf_range(-5, 5))
		tween.tween_property(node, "position", original_pos + offset, 0.05)
	tween.tween_property(node, "position", original_pos, 0.05)

func glitch_effect(node: Control):
	var tween = node.create_tween()
	for i in range(3):
		tween.tween_callback(func(): node.modulate = Color.RED)
		tween.tween_interval(0.05)
		tween.tween_callback(func(): node.modulate = Color.CYAN)
		tween.tween_interval(0.05)
		tween.tween_callback(func(): node.modulate = Color.WHITE)
