extends Node

func play_sound(sound_name: String):
	# Placeholder for sound playing logic
	# In a real Godot project, we would have an AudioStreamPlayer pool here
	print("Audio: Playing ", sound_name)

func play_typing():
	var sounds = ["click1", "click2", "click3"]
	play_sound(sounds[randi() % sounds.size()])

func play_notification():
	play_sound("notification_bell")
