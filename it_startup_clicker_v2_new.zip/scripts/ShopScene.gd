extends Control

@onready var items_container = %ItemsContainer
@onready var stage_progress_label = %StageProgressLabel
@onready var move_button = %MoveButton

var item_data = {
	"keyboard": {"name": "Тихая клавиатура", "cost": 50, "inc": 50, "desc": "Чтобы не будить соседей по ночам (+50% к клику)"},
	"pc": {"name": "Б/У Системник", "cost": 250, "inc": 150, "desc": "Шумит, греется, но компилирует! (+2 к силе клика)"},
	"hired_coders": {"name": "Нанять джуна", "cost": 1000, "inc": 500, "desc": "Пишет код за вас (Пассивный доход)"},
	"servers": {"name": "Аренда сервера", "cost": 5000, "inc": 2000, "desc": "Масштабирование (Большой пассивный доход)"},
	"js_unlock": {"name": "Изучить JavaScript", "cost": 3000, "inc": 0, "desc": "Открывает новый язык программирования"},
	"cpp_unlock": {"name": "Изучить C++", "cost": 15000, "inc": 0, "desc": "Открывает высокопроизводительный язык"},
}

var stage_thresholds = {
	GameManager.Stage.APARTMENT: 1000,
	GameManager.Stage.JOB: 10000,
	GameManager.Stage.COMPANY: 100000
}

func _ready():
	ThemeManager.apply_glass_theme(self)
	_update_shop()
	GameManager.money_changed.connect(un_check_prices)

func _update_shop():
	for child in items_container.get_children():
		child.queue_free()
	
	for id in item_data.keys():
		var data = item_data[id]
		
		# Special handling for unlocks
		if id == "js_unlock" and GameManager.languages["JavaScript"].unlocked: continue
		if id == "cpp_unlock" and GameManager.languages["C++"].unlocked: continue
		
		var current_count = GameManager.upgrades.get(id, 0)
		var current_cost = data.cost + (current_count * data.inc)
		
		var btn = Button.new()
		var count_text = " [У вас: " + str(current_count) + "]" if data.inc > 0 else ""
		btn.text = data.name + " (" + str(current_cost) + " L-C)\n" + data.desc + count_text
		btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		btn.pressed.connect(_on_buy_pressed.bind(id, current_cost))
		items_container.add_child(btn)
	
	_update_progression()

func un_check_prices(_amount):
	_update_progression()

func _update_progression():
	var current_stage = GameManager.current_stage
	var threshold = stage_thresholds[current_stage]
	
	stage_progress_label.text = "Прогресс до переезда: " + str(floor(GameManager.l_coins)) + " / " + str(threshold)
	
	if GameManager.l_coins >= threshold and current_stage < GameManager.Stage.COMPANY:
		move_button.disabled = false
		move_button.text = "ПЕРЕЕХАТЬ / СМЕНИТЬ СТАТУС"
	else:
		move_button.disabled = true
		if current_stage == GameManager.Stage.COMPANY:
			move_button.text = "МАКСИМАЛЬНЫЙ УРОВЕНЬ ДОСТИГНУТ"
		else:
			move_button.text = "Нужно больше L-Coins"

func _on_buy_pressed(id, cost):
	if id == "js_unlock":
		if GameManager.spend_money(cost):
			GameManager.languages["JavaScript"].unlocked = true
			_update_shop()
			return
	if id == "cpp_unlock":
		if GameManager.spend_money(cost):
			GameManager.languages["C++"].unlocked = true
			_update_shop()
			return

	if GameManager.buy_upgrade(id, cost):
		_update_shop()

func _on_move_button_pressed():
	var next_stage = GameManager.current_stage + 1
	var lines = []
	
	match next_stage:
		GameManager.Stage.JOB:
			lines = [
				{"name": GameManager.player_name, "text": "Пора признать — дома работать сложно. Постоянно отвлекаюсь на холодильник."},
				{"name": GameManager.player_name, "text": "Я нашел отличную вакансию. Полное трудоустройство, стабильная зарплата и нормальное рабочее место."},
				{"name": GameManager.player_name, "text": "Это временный этап, чтобы накопить капитал для своей империи."},
				{"name": "Система", "text": "Вы перешли на этап 'Работа по найму'. Сила клика увеличена!"}
			]
		GameManager.Stage.COMPANY:
			lines = [
				{"name": GameManager.player_name, "text": "Этот день настал. У меня достаточно опыта и денег, чтобы уйти от 'дяди'."},
				{"name": GameManager.player_name, "text": "Я снимаю свой первый офис. Начинаю нанимать людей."},
				{"name": GameManager.player_name, "text": "Теперь я не просто кодер. Я — Генеральный директор!"},
				{"name": "Система", "text": "Вы открыли свою IT-компанию! Теперь вы можете нанимать сотрудников и захватывать рынок."}
			]

	if GameManager.advance_stage():
		if lines.size() > 0:
			DialogueManager.show_dialogue(lines)
		_update_shop()
		_update_progression()
