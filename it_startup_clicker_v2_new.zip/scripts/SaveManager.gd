extends Node

const SAVE_PATH = "user://savegame.json"

func save_game():
	var data = GameManager.get_save_data()
	var json_string = JSON.stringify(data)
	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(json_string)
		file.close()
		print("Game Saved")
	else:
		print("Failed to save game")

func load_game():
	if not FileAccess.file_exists(SAVE_PATH):
		print("No save file found")
		return
	
	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file:
		var json_string = file.get_as_text()
		file.close()
		
		var json = JSON.new()
		var parse_result = json.parse(json_string)
		if parse_result == OK:
			var data = json.get_data()
			GameManager.load_save_data(data)
			print("Game Loaded")
		else:
			print("JSON Parse Error: ", json.get_error_message())
	else:
		print("Failed to load game")
