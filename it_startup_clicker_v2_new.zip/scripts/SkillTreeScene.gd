extends Control

@onready var skill_list = VBoxContainer.new()

func _ready():
	ThemeManager.apply_glass_theme(self)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(scroll)
	scroll.add_child(skill_list)
	_update_skills()

func _update_skills():
	for child in skill_list.get_children(): child.queue_free()
	
	for id in GameManager.skill_tree.keys():
		var s = GameManager.skill_tree[id]
		var hbox = HBoxContainer.new()
		
		var info = Label.new()
		var current_cost = s.cost * (s.level + 1)
		info.text = "%s (Lvl %d/%d)\n%s" % [id.capitalize(), s.level, s.max, s.desc]
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(info)
		
		if s.level < s.max:
			var buy_btn = Button.new()
			buy_btn.text = "Улучшить (%d L-C)" % current_cost
			buy_btn.pressed.connect(_on_skill_pressed.bind(id))
			hbox.add_child(buy_btn)
		else:
			var max_lbl = Label.new()
			max_lbl.text = "МАКСИМУМ"
			max_lbl.modulate = Color.GOLD
			hbox.add_child(max_lbl)
			
		skill_list.add_child(hbox)

func _on_skill_pressed(id):
	if GameManager.buy_skill(id):
		_update_skills()
		AudioManager.play_sound("upgrade")
