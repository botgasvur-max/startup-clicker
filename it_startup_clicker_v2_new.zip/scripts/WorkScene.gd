extends Control

@onready var prompt_label = %PromptLabel
@onready var feedback_label = %FeedbackLabel
@onready var code_display = %CodeDisplay
@onready var lang_selector = %LangSelector

var current_key = ""
var keys = ["W", "A", "S", "D", "J", "K", "L", "I"] # Expanded keys
var is_bug_active = false
var bug_count = 0
var is_hacking_mode = false

var code_snippets = {
	"Python": ["print('Hello World')", "def solve():", "  import math", "  return True"],
	"JavaScript": ["console.log('web');", "const api = fetch()", "export default class"],
	"C++": ["std::cout << 'fast';", "int main() {", "template <typename T>", "#include <vector>"],
	"Rust": ["fn main() {", "let mut x = 5;", "println!('Safety first');", "match result {"]
}

func _ready():
	ThemeManager.apply_glass_theme(self)
	_update_lang_selector()
	GameManager.news_updated.connect(_on_news_update)
	if GameManager.tutorial_step == 0:
		_start_tutorial()
	else:
		_spawn_new_key()

func _start_tutorial():
	prompt_label.text = ">>> НАЖМИ ПРОБЕЛ <<<"
	current_key = "Space"
	prompt_label.modulate = Color.YELLOW
	code_display.text += ">>> ОШИБКА ЗАГРУЗКИ. Нажмите Пробел, чтобы перезагрузить BIOS...\n"
	
	var tween = create_tween().set_loops()
	tween.tween_property(prompt_label, "modulate:a", 0.3, 0.5)
	tween.tween_property(prompt_label, "modulate:a", 1.0, 0.5)

func _finish_tutorial():
	GameManager.tutorial_step = 1
	var lines = [
		{"name": "Система", "text": "BIOS восстановлен. Теперь вы можете использовать WASD для написания кода."},
		{"name": GameManager.player_name, "text": "Отлично, теперь за работу!"}
	]
	DialogueManager.show_dialogue(lines)
	_spawn_new_key()

func _update_lang_selector():
	lang_selector.clear()
	for lang in GameManager.languages.keys():
		if GameManager.languages[lang].unlocked:
			lang_selector.add_item(lang)
	
	# Select current
	for i in range(lang_selector.item_count):
		if lang_selector.get_item_text(i) == GameManager.current_language:
			lang_selector.select(i)

func _on_news_update(news_text: String):
	if "АТАКА" in news_text:
		_start_hacking_mini_game()

func _start_hacking_mini_game():
	is_hacking_mode = true
	is_bug_active = true
	bug_count = 15
	prompt_label.text = "ОТРАЗИ ХАКЕРСКУЮ АТАКУ!"
	prompt_label.modulate = Color.RED
	code_display.text += ">>> [CRITICAL] FIREWALL BREACH DETECTED!\n"

func _input(event):
	if event is InputEventKey and event.pressed:
		var key_pressed = OS.get_keycode_string(event.keycode)
		
		if GameManager.tutorial_step == 0:
			if key_pressed == "Space":
				_finish_tutorial()
			return

		if key_pressed == current_key:
			if is_bug_active:
				_resolve_bug()
			else:
				_on_success()
		elif key_pressed in keys:
			_on_failure()

func _spawn_new_key():
	if randf() < 0.1 and not is_bug_active: # 10% chance for a bug
		_trigger_bug()
	
	var active_keys = ["W", "A", "S", "D"]
	if GameManager.level > 5: active_keys += ["J", "K", "L", "I"]
	
	current_key = active_keys[randi() % active_keys.size()]
	
	if is_bug_active:
		prompt_label.text = "ИСПРАВЬ БАГ: " + current_key
		prompt_label.modulate = Color.ORANGE_RED
	else:
		prompt_label.text = "Нажми: " + current_key
		prompt_label.modulate = Color.WHITE

func _trigger_bug():
	is_bug_active = true
	bug_count = randi_range(3, 5) # Need to press 3-5 keys to fix
	code_display.text += ">>> [ERROR] Critical Bug detected!\n"

func _resolve_bug():
	bug_count -= 1
	if bug_count <= 0:
		is_bug_active = false
		if is_hacking_mode:
			is_hacking_mode = false
			GameManager.add_xp(200)
			GameManager.add_money(1000)
			feedback_label.text = "АТАКА ОТРАЖЕНА! +1000 L-C"
			GameManager.news_updated.emit("Хакеры отступили. Система в безопасности.")
		else:
			GameManager.add_xp(50) # Bonus XP for fixing bugs
			feedback_label.text = "Баг исправлен! +50 XP"
		feedback_label.modulate = Color.CYAN
		_animate_feedback()
	_spawn_new_key()

func _on_success():
	GameManager.add_money(GameManager.click_multiplier)
	GameManager.add_xp(5)
	AudioManager.play_typing()
	
	if GameManager.current_project_type != "":
		GameManager.project_progress += 1.0 # Contribution to product
	
	feedback_label.text = "+" + str(floor(GameManager.click_multiplier)) + " L-C"
	feedback_label.modulate = Color.GREEN
	
	var lang = GameManager.current_language
	var snippets = code_snippets.get(lang, ["...working..."])
	code_display.text += snippets[randi() % snippets.size()] + "\n"
	
	if code_display.text.count("\n") > 15:
		var lines = code_display.text.split("\n")
		code_display.text = "\n".join(lines.slice(1))
		
	_spawn_new_key()
	_animate_feedback()

func _on_failure():
	feedback_label.text = "ОШИБКА!"
	feedback_label.modulate = Color.RED
	_animate_feedback()

func _animate_feedback():
	feedback_label.scale = Vector2.ONE * 0.5
	var tween = create_tween()
	tween.set_parallel(true)
	tween.tween_property(feedback_label, "modulate:a", 1.0, 0.1)
	tween.tween_property(feedback_label, "scale", Vector2.ONE, 0.2).set_trans(Tween.TRANS_BACK)
	
	await get_tree().create_timer(0.3).timeout
	var fade = create_tween()
	fade.tween_property(feedback_label, "modulate:a", 0.0, 0.4)

func _on_lang_selector_item_selected(index):
	GameManager.current_language = lang_selector.get_item_text(index)
	GameManager.calculate_multipliers()
	code_display.text += ">>> Switched to " + GameManager.current_language + "\n"
