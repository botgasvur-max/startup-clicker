extends Control

@onready var competitor_list = %CompetitorList
@onready var market_label = %MarketLabel

func _ready():
	ThemeManager.apply_glass_theme(self)
	# Update market info periodically
	var timer = Timer.new()
	timer.wait_time = 10.0
	timer.autostart = true
	timer.timeout.connect(_update_market_view)
	add_child(timer)
	_update_market_view()

func _update_market_view():
	for child in competitor_list.get_children(): child.queue_free()
	
	var player_share = _calculate_player_share()
	market_label.text = "Ваша доля рынка: %d%%" % player_share
	
	for comp_name in GameManager.competitors.keys():
		var comp = GameManager.competitors[comp_name]
		var hbox = HBoxContainer.new()
		
		var lbl = Label.new()
		lbl.text = "%s | Доля рынка: %d%% | Агрессивность: %.1f" % [comp_name, comp.market_share, comp.aggression]
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(lbl)
		
		var sabotage_btn = Button.new()
		sabotage_btn.text = "Саботаж (5000 L-C)"
		sabotage_btn.pressed.connect(_sabotage_competitor.bind(comp_name))
		hbox.add_child(sabotage_btn)
		
		competitor_list.add_child(hbox)

func _calculate_player_share() -> int:
	var total_users = 0
	for p in GameManager.active_products: total_users += p.users
	
	if total_users == 0: return 0
	# Very simplified share logic
	return min(100, int(total_users / 1000.0))

func _sabotage_competitor(comp_name):
	if GameManager.spend_money(5000):
		GameManager.competitors[comp_name].market_share = max(0, GameManager.competitors[comp_name].market_share - 5)
		GameManager.karma -= 5
		GameManager.news_updated.emit("СЛУХИ: " + comp_name + " столкнулась с техническими проблемами...")
		_update_market_view()
