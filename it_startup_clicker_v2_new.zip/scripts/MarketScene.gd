extends Control

@onready var stock_list = %StockList
@onready var balance_label = %BalanceLabel

func _ready():
	ThemeManager.apply_glass_theme(self)
	EventManager.stock_prices_updated.connect(_update_stocks)
	_update_stocks()

func _update_stocks():
	for child in stock_list.get_children():
		child.queue_free()
	
	balance_label.text = "Ваш баланс: " + str(floor(GameManager.l_coins)) + " L-C"
	
	for s_name in GameManager.stocks.keys():
		var stock = GameManager.stocks[s_name]
		var hbox = HBoxContainer.new()
		
		var name_lbl = Label.new()
		name_lbl.text = s_name
		name_lbl.custom_minimum_size.x = 100
		hbox.add_child(name_lbl)
		
		var price_lbl = Label.new()
		price_lbl.text = str(snapped(stock.price, 0.01)) + " L-C"
		price_lbl.custom_minimum_size.x = 100
		hbox.add_child(price_lbl)
		
		var owned_lbl = Label.new()
		owned_lbl.text = "Владеете: " + str(stock.owned)
		owned_lbl.custom_minimum_size.x = 120
		hbox.add_child(owned_lbl)
		
		var buy_btn = Button.new()
		buy_btn.text = "Купить"
		buy_btn.pressed.connect(_buy_stock.bind(s_name))
		hbox.add_child(buy_btn)
		
		var sell_btn = Button.new()
		sell_btn.text = "Продать"
		sell_btn.pressed.connect(_sell_stock.bind(s_name))
		hbox.add_child(sell_btn)
		
		stock_list.add_child(hbox)

func _buy_stock(s_name):
	var price = GameManager.stocks[s_name].price
	if GameManager.spend_money(price):
		GameManager.stocks[s_name].owned += 1
		_update_stocks()

func _sell_stock(s_name):
	if GameManager.stocks[s_name].owned > 0:
		var price = GameManager.stocks[s_name].price
		GameManager.stocks[s_name].owned -= 1
		GameManager.add_money(price)
		_update_stocks()
