extends Node

signal dialogue_finished

func show_dialogue(lines: Array):
	var dialogue_ui = load("res://scenes/DialogueUI.tscn").instantiate()
	get_tree().root.add_child(dialogue_ui)
	dialogue_ui.start_dialogue(lines)
	await dialogue_ui.finished
	dialogue_finished.emit()
