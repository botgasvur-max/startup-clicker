extends Control

@onready var tech_list = %TechList

var techs = [
	{"id": "fast_typing", "name": "Скоропечатание", "cost": 1000, "desc": "Увеличивает доход от кликов на 20%"},
	{"id": "ai_copilot", "name": "AI Копилот", "cost": 5000, "desc": "Автоматическая помощь в коде (х1.2 ко всему доходу)"},
	{"id": "cloud_computing", "name": "Облачные вычисления", "cost": 20000, "desc": "Удваивает пассивный доход от серверов"},
	{"id": "cybersecurity", "name": "Кибербезопасность", "cost": 15000, "desc": "Снижает шанс хакерских атак на 50%"}
]

func _ready():
	ThemeManager.apply_glass_theme(self)
	_update_tech_list()

func _update_tech_list():
	for child in tech_list.get_children():
		child.queue_free()
		
	for tech in techs:
		var panel = PanelContainer.new()
		var hbox = HBoxContainer.new()
		panel.add_child(hbox)
		
		var info = Label.new()
		var status = "[ИЗУЧЕНО]" if GameManager.tech_tree[tech.id] else "[НЕ ИЗУЧЕНО]"
		info.text = "%s %s\n%s" % [status, tech.name, tech.desc]
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(info)
		
		var buy_btn = Button.new()
		buy_btn.text = "Изучить (%d L-C)" % tech.cost
		buy_btn.disabled = GameManager.tech_tree[tech.id]
		buy_btn.pressed.connect(_buy_tech.bind(tech.id, tech.cost))
		hbox.add_child(buy_btn)
		
		tech_list.add_child(panel)

func _buy_tech(id, cost):
	if GameManager.spend_money(cost):
		GameManager.tech_tree[id] = true
		GameManager.calculate_multipliers()
		_update_tech_list()
