extends Control

@onready var energy_bar = %EnergyBar
@onready var hunger_bar = %HungerBar
@onready var karma_label = %KarmaLabel
@onready var status_label = %StatusLabel

func _ready():
	ThemeManager.apply_glass_theme(self)
	GameManager.rpg_stats_changed.connect(_update_ui)
	_update_ui()

func _update_ui():
	energy_bar.value = GameManager.energy
	hunger_bar.value = GameManager.hunger
	karma_label.text = "Карма: " + str(GameManager.karma)
	
	if GameManager.energy < 20:
		status_label.text = "Статус: Истощен (Штраф к доходу)"
	elif GameManager.hunger > 80:
		status_label.text = "Статус: Очень голоден"
	else:
		status_label.text = "Статус: В норме"

func _on_eat_button_pressed():
	if GameManager.spend_money(100):
		GameManager.hunger = max(0, GameManager.hunger - 30)
		GameManager.energy = min(100, GameManager.energy + 5)
		_update_ui()

func _on_sleep_button_pressed():
	# Skip time and restore energy
	GameManager.energy = 100
	GameManager.hunger = min(100, GameManager.hunger + 20)
	# Trigger a few stock updates
	for i in range(5): EventManager._update_stocks()
	_update_ui()

func _on_charity_button_pressed():
	if GameManager.spend_money(500):
		GameManager.karma = min(100, GameManager.karma + 10)
		_update_ui()
