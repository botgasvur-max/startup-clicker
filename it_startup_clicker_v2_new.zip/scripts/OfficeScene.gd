extends Control

@onready var module_list = %ModuleList

var modules = [
	{"id": "coffee_machine", "name": "Кофемашина", "cost": 2000, "desc": "Больше энергии сотрудникам (+10% пассивный доход)"},
	{"id": "bean_bags", "name": "Кресла-мешки", "cost": 1500, "desc": "Улучшает настроение команды"},
	{"id": "server_rack", "name": "Серверная стойка", "cost": 10000, "desc": "Дополнительный пассивный доход (+100 L-C/сек)"}
]

func _ready():
	ThemeManager.apply_glass_theme(self)
	_update_list()

func _update_list():
	for child in module_list.get_children():
		child.queue_free()
	
	for mod in modules:
		var panel = PanelContainer.new()
		var hbox = HBoxContainer.new()
		panel.add_child(hbox)
		
		var val = GameManager.office_modules[mod.id]
		var status = ""
		if typeof(val) == TYPE_BOOL:
			status = "[КУПЛЕНО]" if val else ""
		else:
			status = "[Уровень: " + str(val) + "]"
			
		var info = Label.new()
		info.text = "%s %s\n%s" % [status, mod.name, mod.desc]
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(info)
		
		var buy_btn = Button.new()
		buy_btn.text = "Купить/Улучшить (%d L-C)" % mod.cost
		if typeof(val) == TYPE_BOOL and val:
			buy_btn.disabled = true
		buy_btn.pressed.connect(_buy_module.bind(mod.id, mod.cost))
		hbox.add_child(buy_btn)
		
		module_list.add_child(panel)

func _buy_module(id, cost):
	if GameManager.spend_money(cost):
		var val = GameManager.office_modules[id]
		if typeof(val) == TYPE_BOOL:
			GameManager.office_modules[id] = true
		else:
			GameManager.office_modules[id] += 1
		
		GameManager.calculate_multipliers()
		_update_list()
