extends Control

@onready var part_list = %PartList

var catalog = {
	"cpu": [
		{"name": "Intel Core i3-ish", "cost": 500, "power": 1.5},
		{"name": "Ryzen 7-ish", "cost": 2000, "power": 3.0},
		{"name": "Threadripper", "cost": 10000, "power": 10.0}
	],
	"gpu": [
		{"name": "GTX 1050-ish", "cost": 800, "power": 1.5},
		{"name": "RTX 3080-ish", "cost": 3000, "power": 4.0},
		{"name": "H100 Tensor Core", "cost": 50000, "power": 25.0}
	],
	"ram": [
		{"name": "16GB DDR4", "cost": 300, "power": 1.2},
		{"name": "64GB DDR5", "cost": 1200, "power": 2.5},
		{"name": "256GB ECC", "cost": 8000, "power": 6.0}
	]
}

func _ready():
	ThemeManager.apply_glass_theme(self)
	_update_catalog()

func _update_catalog():
	for child in part_list.get_children():
		child.queue_free()
		
	for type in catalog.keys():
		var label = Label.new()
		label.text = "--- " + type.to_upper() + " ---"
		part_list.add_child(label)
		
		for item in catalog[type]:
			var hbox = HBoxContainer.new()
			var info = Label.new()
			var current = " [УСТАНОВЛЕНО]" if GameManager.pc_parts[type].name == item.name else ""
			info.text = "%s %s (Мощность: x%.1f)" % [current, item.name, item.power]
			info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			hbox.add_child(info)
			
			var buy_btn = Button.new()
			buy_btn.text = "Купить (%d L-C)" % item.cost
			buy_btn.disabled = GameManager.pc_parts[type].name == item.name
			buy_btn.pressed.connect(_buy_part.bind(type, item))
			hbox.add_child(buy_btn)
			
			part_list.add_child(hbox)

func _buy_part(type, data):
	if GameManager.spend_money(data.cost):
		GameManager.pc_parts[type] = {"name": data.name, "power": data.power}
		GameManager.calculate_multipliers()
		_update_catalog()
