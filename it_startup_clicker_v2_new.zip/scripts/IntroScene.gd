extends Control

@onready var name_input = %NameInput
@onready var start_button = %StartButton
@onready var origin_desc = %OriginDesc
@onready var origin_selector = %OriginSelector

var origins = {
	"student": {
		"name": "Студент-должник",
		"desc": "Вы закончили вуз с долгом 5000 L-C. 50% дохода идет на погашение. БОНУС: Опыт набирается на 30% быстрее.",
		"setup": {"debt": 5000, "coins": 0, "karma": 0}
	},
	"hacker": {
		"name": "Случайный хакер",
		"desc": "Вы случайно взломали пиццерию. БОНУС: Сила клика +50%, но полиция может вами заинтересоваться.",
		"setup": {"debt": 0, "coins": 500, "karma": -10}
	},
	"garage": {
		"name": "Наследство в гараже",
		"desc": "Дед оставил вам гараж и старый компьютер. БОНУС: У вас сразу есть уникальное оборудование, но мало энергии.",
		"setup": {"debt": 0, "coins": 100, "karma": 0, "energy": 50}
	},
	"viral": {
		"name": "Виральный ролик",
		"desc": "Ваше видео стало хитом! БОНУС: Хайп сразу х2, но он быстро падает. Начните с 0 денег.",
		"setup": {"debt": 0, "coins": 0, "karma": 0, "hype": 2.0}
	}
}

var selected_origin = "student"

func _ready():
	if GameManager.intro_completed:
		get_tree().change_scene_to_file("res://scenes/Main.tscn")
	
	_update_origin_info()

func _on_origin_selector_item_selected(index):
	selected_origin = origins.keys()[index]
	_update_origin_info()

func _update_origin_info():
	origin_desc.text = origins[selected_origin].desc

func _on_start_button_pressed():
	var p_name = name_input.text.strip_edges()
	if p_name == "": p_name = "Программист"
	
	GameManager.player_name = p_name
	GameManager.origin_id = selected_origin
	
	# Apply setup
	var setup = origins[selected_origin].setup
	GameManager.debt_amount = setup.get("debt", 0)
	GameManager.l_coins = setup.get("coins", 0)
	GameManager.karma = setup.get("karma", 0)
	GameManager.energy = setup.get("energy", 100)
	GameManager.hype = setup.get("hype", 1.0)
	
	_start_intro()

func _start_intro():
	start_button.disabled = true
	var lines = []
	
	match selected_origin:
		"student":
			lines = [
				{"name": GameManager.player_name, "text": "Диплом в кармане, а в банке — огромная дыра. Кредит за обучение сам себя не выплатит."},
				{"name": GameManager.player_name, "text": "Придется пахать. 50% каждого чека будет списываться банком, пока я не стану свободным."},
				{"name": GameManager.player_name, "text": "Зато знания свежие. Пора показать этим корпорациям, на что способен выпускник!"}
			]
		"hacker":
			lines = [
				{"name": GameManager.player_name, "text": "Я просто хотел заказать пепперони бесплатно... А в итоге залез в базу данных всей сети."},
				{"name": GameManager.player_name, "text": "У меня на счету 500 L-C от 'анонимного пожертвования' самого себе. Но за мной могут следить."},
				{"name": GameManager.player_name, "text": "Буду использовать свои 'скрипты', чтобы писать код быстрее остальных."}
			]
		"garage":
			lines = [
				{"name": GameManager.player_name, "text": "Дед всегда говорил, что в этом гараже зарыто золото. Оказалось — это старый сервер 90-х."},
				{"name": GameManager.player_name, "text": "Тут пыльно, пахнет бензином и мало света. Энергия на нуле, но атмосфера стартапа — то что надо!"}
			]
		"viral":
			lines = [
				{"name": GameManager.player_name, "text": "Миллион просмотров за ночь?! Весь IT-Twitter обсуждает мой туториал по Python."},
				{"name": GameManager.player_name, "text": "Денег пока нет, но все ждут от меня новый проект. Пока я на хайпе, нужно ковать железо!"}
			]
	
	await DialogueManager.show_dialogue(lines)
	
	# Initial Mentor Meeting
	var mentor_lines = [
		{"name": "Наставник (Ментор)", "text": "Эй, я видел твои наброски кода. Неплохо для начала."},
		{"name": "Наставник (Ментор)", "text": "Слушай, в IT есть два пути. Один — честный, но медленный. Другой — быстрый, но грязный."},
		{"name": "Наставник (Ментор)", "text": "К какому берегу прибьёт тебя? Помни, корпорация Macrosoft всегда следит за талантами."}
	]
	await DialogueManager.show_dialogue(mentor_lines)
	
	GameManager.intro_completed = true
	get_tree().change_scene_to_file("res://scenes/Main.tscn")
