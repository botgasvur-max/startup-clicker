extends Control

signal finished

@onready var text_label = %DialogueText
@onready var name_label = %NameLabel

var dialogue_lines = []
var current_line = 0

func start_dialogue(lines: Array):
	dialogue_lines = lines
	current_line = 0
	_show_line()

func _input(event):
	if event is InputEventMouseButton and event.pressed:
		_next_line()
	elif event is InputEventKey and event.pressed and event.keycode == KEY_SPACE:
		_next_line()

func _next_line():
	current_line += 1
	if current_line < dialogue_lines.size():
		_show_line()
	else:
		finished.emit()
		queue_free()

func _show_line():
	var line_data = dialogue_lines[current_line]
	name_label.text = line_data.get("name", GameManager.player_name)
	text_label.text = line_data.get("text", "")
	
	# Simple typewriter effect
	text_label.visible_ratio = 0.0
	var tween = create_tween()
	tween.tween_property(text_label, "visible_ratio", 1.0, 0.5)
