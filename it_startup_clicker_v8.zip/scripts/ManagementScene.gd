extends Control

@onready var employee_list = %EmployeeList
@onready var hire_button = %HireButton

var names = ["Алексей", "Дмитрий", "Елена", "Мария", "Иван", "Ольга", "Сергей", "Анна"]
var roles = ["Frontend", "Backend", "QA", "DevOps"]
var traits = [
	{"name": "Гений", "mult": 2.0, "mood_drain": 1.5, "desc": "х2 Продуктивность, но капризный"},
	{"name": "Трудоголик", "mult": 1.2, "mood_drain": 0.5, "desc": "Всегда в хорошем настроении"},
	{"name": "Лентяй", "mult": 0.5, "mood_drain": 0.1, "desc": "Почти не работает, но дешев"},
	{"name": "Обычный", "mult": 1.0, "mood_drain": 1.0, "desc": "Стандартный кодер"}
]

func _ready():
	ThemeManager.apply_glass_theme(self)
	_update_list()
	
	# Salary timer
	var timer = Timer.new()
	timer.wait_time = 60.0
	timer.autostart = true
	timer.timeout.connect(_pay_salaries)
	add_child(timer)

func _update_list():
	for child in employee_list.get_children():
		child.queue_free()
	
	for i in range(GameManager.employees.size()):
		var emp = GameManager.employees[i]
		var panel = PanelContainer.new()
		var is_mentor = emp.get("is_mentor", false)
		
		if is_mentor:
			var style = StyleBoxFlat.new()
			style.bg_color = Color(0.2, 0.3, 0.4, 0.5)
			style.border_width_left = 4
			style.border_color = Color.GOLD
			panel.add_theme_stylebox_override("panel", style)

		var hbox = HBoxContainer.new()
		panel.add_child(hbox)
		
		var info = Label.new()
		var t_name = emp.get("trait", "Обычный")
		var vacation_status = " [В ОТПУСКЕ]" if emp.get("is_on_vacation", false) else ""
		var salary_text = "Зарплата: %d L-C" % emp.salary if not is_mentor else "СОВЛАДЕЛЕЦ"
		
		info.text = "%s (%s) [%s]%s\nСкилл: %d | Настроение: %d%% | Стресс: %d%%\n%s" % [emp.name, emp.role, t_name, vacation_status, emp.skill, emp.mood, emp.get("stress", 0), salary_text]
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(info)
		
		var v_box = VBoxContainer.new()
		hbox.add_child(v_box)

		var vacation_btn = Button.new()
		vacation_btn.text = "В отпуск"
		vacation_btn.disabled = emp.get("is_on_vacation", false)
		vacation_btn.pressed.connect(_send_on_vacation.bind(i))
		v_box.add_child(vacation_btn)

		var train_btn = Button.new()
		train_btn.text = "Обучить (500 L-C)"
		train_btn.pressed.connect(_train_employee.bind(i))
		v_box.add_child(train_btn)
		
		var fire_btn = Button.new()
		fire_btn.text = "УВОЛИТЬ"
		fire_btn.modulate = Color.RED
		if is_mentor:
			fire_btn.disabled = true
			fire_btn.text = "НЕЗАМЕНИМ"
		fire_btn.pressed.connect(_fire_employee.bind(i))
		v_box.add_child(fire_btn)
		
		employee_list.add_child(panel)

func _on_hire_button_pressed():
	if GameManager.spend_money(2000):
		var t = traits[randi() % traits.size()]
		var new_emp = {
			"name": names[randi() % names.size()],
			"role": roles[randi() % roles.size()],
			"skill": randi_range(10, 30) * t.mult,
			"mood": 100,
			"stress": 0,
			"salary": randi_range(100, 300),
			"trait": t.name,
			"mood_mult": t.mood_drain,
			"is_on_vacation": false
		}
		GameManager.employees.append(new_emp)
		GameManager.calculate_multipliers()
		_update_list()

func _train_employee(index):
	if GameManager.spend_money(500):
		GameManager.employees[index].skill += 5
		GameManager.calculate_multipliers()
		_update_list()

func _send_on_vacation(index):
	GameManager.employees[index].is_on_vacation = true
	GameManager.calculate_multipliers()
	_update_list()

func _fire_employee(index):
	if GameManager.fire_employee(index):
		_update_list()

func _pay_salaries():
	var total_salary = 0
	for emp in GameManager.employees:
		total_salary += emp.salary
	
	if not GameManager.spend_money(total_salary):
		# Penalize mood if can't pay
		for i in range(GameManager.employees.size()):
			GameManager.employees[i].mood = max(0, GameManager.employees[i].mood - 20)
	else:
		# Boost mood if paid
		for i in range(GameManager.employees.size()):
			GameManager.employees[i].mood = min(100, GameManager.employees[i].mood + 5)
	
	GameManager.calculate_multipliers()
	_update_list()
