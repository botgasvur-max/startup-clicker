extends Node

signal quests_updated

var story_quests = []

func _init_quests():
	story_quests = [
		{
			"id": "intro_work",
			"title": "Начало пути",
			"desc": "Заработать первые 500 L-C на фрилансе.",
			"target_money": 500,
			"completed": false,
			"next_quest": "home_setup"
		},
		{
			"id": "home_setup",
			"title": "Домашний офис",
			"desc": "Установить домашний сервер (уровень 1).",
			"require_module": "home_server_tier",
			"target_value": 1,
			"completed": false,
			"next_quest": "reach_startup"
		},
		{
			"id": "reach_startup",
			"title": "Выход в свет",
			"desc": "Переехать в коворкинг (Этап: Стартап).",
			"require_stage": GameManager.Stage.STARTUP,
			"completed": false,
			"next_quest": "first_team"
		},
		{
			"id": "first_team",
			"title": "Команда",
			"desc": "Нанять первого сотрудника.",
			"require_employees": 1,
			"completed": false,
			"next_quest": "macrosoft_rumors"
		},
		{
			"id": "macrosoft_rumors",
			"title": "Слухи о Macrosoft",
			"desc": "Накопить 50,000 L-C для подготовки к атаке.",
			"target_money": 50000,
			"completed": false,
			"next_quest": "reach_tech_corp"
		},
		{
			"id": "reach_tech_corp",
			"title": "Корпоративная война",
			"desc": "Стать Техно-Корпорацией.",
			"require_stage": GameManager.Stage.TECH_CORP,
			"completed": false,
			"next_quest": "server_farm"
		},
		{
			"id": "server_farm",
			"title": "Серверная ферма",
			"desc": "Установить 100 серверов.",
			"require_servers": 100,
			"completed": false,
			"next_quest": "final_bunker"
		},
		{
			"id": "final_bunker",
			"title": "Последний рубеж",
			"desc": "Построить Секретный Бункер и завершить месть.",
			"require_stage": GameManager.Stage.BUNKER,
			"completed": false
		}
	]

var active_chain = []

var hacking_contracts = [
	{"id": "hack_wifi", "title": "Взлом Wi-Fi соседа", "reward": 200, "risk": 5, "skill_req": 0, "align_impact": -2},
	{"id": "db_leak", "title": "Слив базы данных", "reward": 1500, "risk": 20, "skill_req": 2, "align_impact": -10},
	{"id": "bank_bypass", "title": "Обход банковской защиты", "reward": 5000, "risk": 50, "skill_req": 5, "align_impact": -25},
	{"id": "crypto_drain", "title": "Опустошение криптокошелька", "reward": 3000, "risk": 35, "skill_req": 3, "align_impact": -15},
	{"id": "corporate_espionage", "title": "Корпоративный шпионаж", "reward": 8000, "risk": 60, "skill_req": 7, "align_impact": -30}
]

func _ready():
	_init_quests()
	var timer = Timer.new()
	timer.wait_time = 10.0
	timer.autostart = true
	timer.timeout.connect(_check_quests)
	add_child(timer)

func _check_quests():
	var changed = false
	for q in story_quests:
		if q["completed"]: continue
		
		# Only check the current quest in the chain (sequential logic)
		var q_idx = story_quests.find(q)
		if q_idx > 0 and not story_quests[q_idx - 1]["completed"]:
			continue

		var is_done = false
		if q.has("target_money") and GameManager.l_coins >= q["target_money"]:
			is_done = true
		elif q.has("require_module") and GameManager.office_modules[q["require_module"]] >= q["target_value"]:
			is_done = true
		elif q.has("require_stage") and GameManager.current_stage >= q["require_stage"]:
			is_done = true
		elif q.has("require_employees") and GameManager.employees.size() >= q["require_employees"]:
			is_done = true
		elif q.has("require_servers") and GameManager.office_modules["server_slots"].size() >= q["require_servers"]:
			is_done = true
			
		if is_done:
			q["completed"] = true
			changed = true
			GameManager.news_updated.emit("ЦЕЛЬ ДОСТИГНУТА: " + q["title"])
			VisualEffectsManager.glitch_effect(get_tree().current_scene)
	
	if changed: quests_updated.emit()

func accept_hacking(contract_id):
	var c = null
	for contract in hacking_contracts:
		if contract.id == contract_id:
			c = contract
			break
	
	if c:
		# Trigger hacking mini-game in WorkScene
		GameManager.news_updated.emit("КОНТРАКТ ПРИНЯТ: " + c.title)
		# We'll use a signal or global state to tell WorkScene to start a hack
		get_tree().root.set_meta("active_hack", c)
