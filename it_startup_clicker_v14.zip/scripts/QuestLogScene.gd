extends Control

@onready var quest_list = VBoxContainer.new()
@onready var hack_list = VBoxContainer.new()

func _ready():
	ThemeManager.apply_glass_theme(self)
	var main_vbox = VBoxContainer.new()
	main_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	add_child(main_vbox)
	
	var q_lbl = Label.new()
	q_lbl.text = "--- СЮЖЕТНЫЕ ЗАДАНИЯ ---"
	main_vbox.add_child(q_lbl)
	main_vbox.add_child(quest_list)
	
	var h_lbl = Label.new()
	h_lbl.text = "\n--- КОНТРАКТЫ (BLACK HAT) ---"
	main_vbox.add_child(h_lbl)
	main_vbox.add_child(hack_list)
	
	_update_ui()
	QuestManager.quests_updated.connect(_update_ui)

func _update_ui():
	for child in quest_list.get_children(): child.queue_free()
	for child in hack_list.get_children(): child.queue_free()
	
	var found_active = false
	for q in QuestManager.story_quests:
		var q_lbl = Label.new()
		if q.completed:
			q_lbl.text = "[ВЫПОЛНЕНО] %s" % q.title
			q_lbl.modulate = Color.DARK_GRAY
			quest_list.add_child(q_lbl)
			continue
			
		if not found_active:
			q_lbl.text = ">>> ТЕКУЩАЯ ЦЕЛЬ: %s <<<\n%s" % [q.title, q.desc]
			q_lbl.modulate = Color.YELLOW
			quest_list.add_child(q_lbl)
			found_active = true
		else:
			q_lbl.text = "[ЗАБЛОКИРОВАНО] %s" % q.title
			q_lbl.modulate = Color.DIM_GRAY
			quest_list.add_child(q_lbl)
		
	for h in QuestManager.hacking_contracts:
		var h_hbox = HBoxContainer.new()
		var h_lbl = Label.new()
		h_lbl.text = "%s (Награда: %d L-C | Риск: %d%%)" % [h.title, h.reward, h.risk]
		h_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h_hbox.add_child(h_lbl)
		
		var h_btn = Button.new()
		h_btn.text = "Принять"
		h_btn.pressed.connect(_accept_hack.bind(h.id))
		h_hbox.add_child(h_btn)
		hack_list.add_child(h_hbox)

func _accept_hack(id):
	QuestManager.accept_hacking(id)
	AudioManager.play_sound("open_window")
