extends Node

signal random_event_triggered(event_data)
signal stock_prices_updated()

var event_timer: Timer
var stock_timer: Timer

var events = [
	{"id": "hacker_attack", "title": "Хакерская атака!", "desc": "Ваши сервера под угрозой.", "type": "negative", "chance": 0.05},
	{"id": "viral_project", "title": "Виральный успех!", "desc": "Доход от кликов х5 на 30 сек.", "type": "positive", "chance": 0.1},
	{"id": "family_visit", "title": "Визит родных", "desc": "Мама принесла пирожки. Голод снижен, но работа встала.", "type": "neutral", "chance": 0.08},
	{"id": "tax_audit", "title": "Налоговая проверка", "desc": "Нужно заплатить штраф или попытаться договориться.", "type": "negative", "chance": 0.03},
	{"id": "crypto_boom", "title": "Крипто-Бум!", "desc": "Цены на GPU взлетели, но доход от майнинга х10.", "type": "neutral", "chance": 0.04},
	{"id": "server_attack", "title": "АТАКА НА СЕРВЕРА", "desc": "Ваши сервера под атакой! Срочно исправьте баги в терминале 'Работа'.", "type": "negative", "chance": 0.03},
	{"id": "macrosoft_poach", "title": "Охота за головами", "desc": "Macrosoft пытается переманить вашего лучшего сотрудника!", "type": "negative", "chance": 0.05},
	{"id": "macrosoft_troll", "title": "Армия ботов", "desc": "Macrosoft запустила кампанию по дезинформации. Фанаты недовольны.", "type": "negative", "chance": 0.06},
	{"id": "it_expo", "title": "IT ВЫСТАВКА", "desc": "Шанс заявить о себе всему миру!", "type": "neutral", "chance": 0.04}
]

func _ready():
	event_timer = Timer.new()
	event_timer.wait_time = 60.0
	event_timer.autostart = true
	event_timer.timeout.connect(_check_for_event)
	add_child(event_timer)
	
	stock_timer = Timer.new()
	stock_timer.wait_time = 30.0
	stock_timer.autostart = true
	stock_timer.timeout.connect(_update_stocks)
	add_child(stock_timer)
	
	var tax_timer = Timer.new()
	tax_timer.wait_time = 120.0 # Taxes every 2 minutes
	tax_timer.autostart = true
	tax_timer.timeout.connect(_pay_taxes)
	add_child(tax_timer)

func _check_for_event():
	for event in events:
		if randf() < event.chance:
			_trigger_event(event)
			break

func _pay_taxes():
	var tax_rate = 0.1 # 10%
	if GameManager.karma < 0: tax_rate = 0.2
	
	var amount = GameManager.l_coins * tax_rate
	if amount > 0:
		GameManager.spend_money(amount)
		GameManager.news_updated.emit("Уплачены налоги: %d L-C" % amount)

func _trigger_event(event):
	random_event_triggered.emit(event)
	
	if event.id == "family_visit":
		GameManager.hunger = max(0, GameManager.hunger - 40)
		GameManager.energy = min(100, GameManager.energy + 10)
	elif event.id == "crypto_boom":
		GameManager.news_updated.emit("КРИПТО-БУМ: Цены на видеокарты растут!")
	elif event.id == "server_attack":
		GameManager.news_updated.emit("КРИТИЧЕСКАЯ АТАКА НА СЕРВЕРА!")
	elif event.id == "macrosoft_poach":
		if GameManager.employees.size() > 0:
			var idx = randi() % GameManager.employees.size()
			var emp = GameManager.employees[idx]
			if not emp.get("is_mentor", false):
				var loss = int(GameManager.fans * 0.05)
				GameManager.fans -= loss
				GameManager.news_updated.emit("Macrosoft переманила %s! Мы потеряли часть фанатов." % emp.name)
				GameManager.employees.remove_at(idx)
				GameManager.calculate_multipliers()
	elif event.id == "macrosoft_troll":
		var loss = int(GameManager.fans * 0.15)
		GameManager.fans -= loss
		GameManager.news_updated.emit("Атака ботов Macrosoft: -%d фанатов" % loss)
	elif event.id == "it_expo":
		_trigger_expo_dialogue()

func _trigger_expo_dialogue():
	var expo_lines = [
		{"name": "Система", "text": "Вас пригласили на крупнейшую IT-выставку года! Как мы представим компанию?"}
	]
	DialogueManager.show_dialogue(expo_lines)
	
	# For simplicity in this env, we'll choose based on money
	if GameManager.l_coins > 100000:
		GameManager.news_updated.emit("ВЫСТАВКА: Мы взяли главный стенд! +5000 фанатов, Хайп х2")
		GameManager.fans += 5000
		GameManager.hype *= 2.0
		GameManager.spend_money(50000)
	else:
		GameManager.news_updated.emit("ВЫСТАВКА: Маленький стенд привлек немного внимания. +200 фанатов.")
		GameManager.fans += 200

func _update_stocks():
	for stock in GameManager.stocks.keys():
		var change = randf_range(-0.1, 0.12)
		GameManager.stocks[stock].price *= (1.0 + change)
		GameManager.stocks[stock].price = max(1.0, GameManager.stocks[stock].price)
	
	# Update Crypto Market Multiplier based on general trends
	var trend = randf_range(0.5, 2.0)
	GameManager.crypto_market_multiplier = trend
	
	stock_prices_updated.emit()
