extends Control

@onready var coin_label = %CoinLabel
@onready var stage_label = %StageLabel
@onready var windows_container = %WindowsContainer
@onready var notification_area = %NotificationArea

var window_scenes = {
	"Work": preload("res://scenes/WorkScene.tscn"),
	"Shop": preload("res://scenes/ShopScene.tscn"),
	"Market": preload("res://scenes/MarketScene.tscn"),
	"Personal": preload("res://scenes/PersonalScene.tscn"),
	"Management": preload("res://scenes/ManagementScene.tscn"),
	"Research": preload("res://scenes/ResearchScene.tscn"),
	"Products": preload("res://scenes/ProductScene.tscn"),
	"Competitive": preload("res://scenes/CompetitiveScene.tscn"),
	"Skills": preload("res://scripts/SkillTreeScene.gd"),
	"Quests": preload("res://scripts/QuestLogScene.gd")
}

func _ready():
	ThemeManager.add_procedural_background(self)
	ThemeManager.apply_glass_theme(self)
	GameManager.money_changed.connect(_on_money_changed)
	GameManager.stage_changed.connect(_on_stage_changed)
	EventManager.random_event_triggered.connect(_on_event_triggered)
	
	_update_ui()
	_on_stage_changed(GameManager.current_stage)
	
	$PassiveTimer.start()
	
	if GameManager.tutorial_step == 0:
		_start_onboarding()

func _start_onboarding():
	var lines = [
		{"name": "Система", "text": "Добро пожаловать в вашу рабочую среду. Это ваш рабочий стол."},
		{"name": "Система", "text": "Все инструменты доступны в панели задач снизу или через иконки на рабочем столе."},
		{"name": "Система", "text": "Ваша первая задача: Починить старый компьютер, чтобы начать работу."},
		{"name": "Система", "text": "Открываю терминал 'Работа'..."}
	]
	await DialogueManager.show_dialogue(lines)
	if is_inside_tree():
		open_app("Work")

func _on_money_changed(amount):
	coin_label.text = str(floor(amount)) + " L-C"

func _on_stage_changed(stage):
	var data = GameManager.STAGE_DATA.get(stage, {})
	stage_label.text = data.get("name", "Unknown Location")
	self.modulate = data.get("color", Color.WHITE)

func _update_ui():
	_on_money_changed(GameManager.l_coins)

func open_app(app_name: String):
	if windows_container.has_node(app_name):
		var existing = windows_container.get_node(app_name)
		existing.show()
		windows_container.move_child(existing, windows_container.get_child_count() - 1)
		return

	var app_res = window_scenes.get(app_name)
	if app_res:
		var window = PanelContainer.new()
		window.name = app_name
		window.custom_minimum_size = Vector2(800, 500)
		
		var vbox = VBoxContainer.new()
		window.add_child(vbox)
		
		# Title Bar
		var title_bar = PanelContainer.new()
		title_bar.custom_minimum_size.y = 30
		var hbox = HBoxContainer.new()
		title_bar.add_child(hbox)
		
		var title_lbl = Label.new()
		title_lbl.text = " " + app_name
		title_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(title_lbl)
		
		var close_btn = Button.new()
		close_btn.text = " X "
		close_btn.pressed.connect(window.queue_free)
		hbox.add_child(close_btn)
		
		vbox.add_child(title_bar)
		
		# Content
		var content
		if app_res is PackedScene:
			content = app_res.instantiate()
		else:
			# It's a GDScript, need to create instance manually
			content = app_res.new()
			
		content.size_flags_vertical = Control.SIZE_EXPAND_FILL
		vbox.add_child(content)
		
		windows_container.add_child(window)
		
		# Animation
		window.scale = Vector2.ZERO
		var tween = create_tween()
		tween.tween_property(window, "scale", Vector2.ONE, 0.2).set_trans(Tween.TRANS_BACK).set_ease(Tween.TRANS_OUT)
		
		AudioManager.play_sound("open_window")

func _on_event_triggered(data):
	show_notification(data.title, data.desc)

func show_notification(n_title: String, n_body: String):
	var note = PanelContainer.new()
	note.custom_minimum_size = Vector2(250, 80)
	var n_vbox = VBoxContainer.new()
	note.add_child(n_vbox)
	
	var t_lbl = Label.new()
	t_lbl.text = n_title
	t_lbl.modulate = Color.YELLOW
	n_vbox.add_child(t_lbl)
	
	var b_lbl = Label.new()
	b_lbl.text = n_body
	b_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD
	b_lbl.add_theme_font_size_override("font_size", 12)
	n_vbox.add_child(b_lbl)
	
	notification_area.add_child(note)
	AudioManager.play_notification()
	
	await get_tree().create_timer(5.0).timeout
	var tween = create_tween()
	tween.tween_property(note, "modulate:a", 0.0, 0.5)
	await tween.finished
	note.queue_free()

func _on_save_pressed(): SaveManager.save_game()
func _on_load_pressed(): SaveManager.load_game()
func _on_passive_timer_timeout(): GameManager.add_money(GameManager.passive_income)
