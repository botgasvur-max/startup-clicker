extends Node

signal money_changed(amount)
signal stage_changed(new_stage)
signal xp_changed(amount)
signal level_up(new_level)
signal reputation_changed(amount)
signal research_points_changed(amount)
signal fans_changed(amount)
signal rpg_stats_changed()
signal news_updated(news_text)

enum Stage { APARTMENT, STARTUP, TECH_CORP, EMPIRE, BUNKER }
enum Alignment { WHITE_HAT, NEUTRAL, BLACK_HAT }

# --- NARRATIVE & ORIGINS ---
var player_name: String = "Программист"
var mentor_opinion: int = 50
var antagonist_pressure: int = 0
var origin_id: String = "none"
var intro_completed: bool = false
var tutorial_step: int = 0
var debt_amount: float = 0.0

var revenge_progress: float = 0.0 # 0 to 100
var macrosoft_stats = {
	"capitalization": 10000000.0,
	"reputation": 95.0
}
var active_quests = []
var completed_milestones = []

# --- RPG STATS ---
var energy: float = 100.0
var hunger: float = 0.0
var health: float = 100.0
var karma: int = 0
var alignment: Alignment = Alignment.NEUTRAL
var alignment_score: int = 0 # -100 (Black) to 100 (White)
var suspicion: float = 0.0 
var family_affinity: int = 50
var max_energy: float = 100.0

# --- CORE CURRENCY ---
var l_coins: float = 0.0:
	set(value):
		l_coins = value
		money_changed.emit(l_coins)

var reputation: float = 0.0:
	set(value):
		reputation = value
		reputation_changed.emit(reputation)

var research_points: float = 0.0:
	set(value):
		research_points = value
		research_points_changed.emit(research_points)

var fans: int = 0:
	set(value):
		fans = value
		fans_changed.emit(fans)

# --- PROGRESSION & ERAS ---
var current_stage: Stage = Stage.APARTMENT:
	set(value):
		current_stage = value
		stage_changed.emit(current_stage)

var current_era: String = "Web 1.0"
var level: int = 1
var xp: float = 0.0:
	set(value):
		xp = value
		var needed = get_xp_needed()
		if xp >= needed:
			xp -= needed
			level += 1
			level_up.emit(level)
		xp_changed.emit(xp)

func get_xp_needed():
	var base = 100 * pow(level, 1.5)
	if origin_id == "student": return base * 0.7
	return base

# --- PRODUCTS & MARKET ---
var active_products = []
var current_project_type = ""
var project_progress = 0.0
var hype = 1.0
var competitors = {
	"Macrosoft": {"market_share": 40, "aggression": 0.5},
	"Pear": {"market_share": 30, "aggression": 0.3},
	"Gooogle": {"market_share": 20, "aggression": 0.7}
}

# --- EQUIPMENT ---
var pc_parts = {
	"cpu": {"name": "Базовый чип", "power": 1.0, "tdp": 35},
	"gpu": {"name": "Встройка", "power": 1.0, "tdp": 10},
	"ram": {"name": "4GB", "power": 1.0, "freq": 2133},
	"cooling": {"name": "Боксовый кулер", "capacity": 50},
	"psu": {"name": "NoName 300W", "wattage": 300}
}

# --- ECONOMY ---
var servers_online: bool = true
var crypto_market_multiplier: float = 1.0

var STAGE_DATA = {
	Stage.APARTMENT: {
		"name": "Гараж / Квартира",
		"rent": 200,
		"living_costs": 150, # Food, bills
		"max_employees": 2,
		"max_servers": 10,
		"color": Color.WHITE
	},
	Stage.STARTUP: {
		"name": "Коворкинг",
		"rent": 1500,
		"living_costs": 800,
		"max_employees": 25,
		"max_servers": 150,
		"color": Color(0.8, 0.9, 1.0)
	},
	Stage.TECH_CORP: {
		"name": "Бизнес-Центр Skyline",
		"rent": 12000,
		"living_costs": 3000,
		"max_employees": 200,
		"max_servers": 1000,
		"color": Color(0.7, 1.0, 0.7)
	},
	Stage.EMPIRE: {
		"name": "Штаб-квартира Цитадель",
		"rent": 80000,
		"living_costs": 15000,
		"max_employees": 1500,
		"max_servers": 5000,
		"color": Color(1.0, 0.8, 0.8)
	},
	Stage.BUNKER: {
		"name": "Секретный Бункер",
		"rent": 0, # Owned
		"living_costs": 50000, # High maintenance
		"max_employees": 10000,
		"max_servers": 25000,
		"color": Color(0.5, 0.2, 0.8)
	}
}

var rent_amount: float = 200.0
var days_passed: int = 0
var last_rent_day: int = 0

var stocks = {
	"Gooogle": {"price": 150.0, "owned": 0},
	"Pear": {"price": 200.0, "owned": 0},
	"Macrosoft": {"price": 120.0, "owned": 0},
	"Nvidia-ish": {"price": 500.0, "owned": 0}
}

# --- COMPANY & EMPLOYEES ---
var employees = []
var office_modules = {
	"coffee_machine": false,
	"bean_bags": false,
	"server_rack": 0,
	"server_slots": [], # Array of levels
	"home_server_tier": 0 # 0 to 5
}

var active_marketing = {
	"social_media": 0, # Ticks remaining
	"tv": 0,
	"ads": 0
}

var marketing_level: int = 0

# --- LANGUAGES ---
var current_language = "Python"
var languages = {
	"Python": {"unlocked": true, "mult": 1.0, "xp_mult": 1.2},
	"JavaScript": {"unlocked": false, "mult": 1.5, "xp_mult": 1.0},
	"C++": {"unlocked": false, "mult": 2.5, "xp_mult": 0.8},
	"Rust": {"unlocked": false, "mult": 4.0, "xp_mult": 1.5}
}

# --- UPGRADES & TECH ---
var upgrades = {
	"keyboard": 0,
	"pc": 0,
	"hired_coders": 0,
	"servers": 0
}

var tech_tree = {
	"fast_typing": false,
	"ai_copilot": false,
	"cloud_computing": false,
	"cybersecurity": false
}

var skill_tree = {
	"languages": {
		"python_basics": {"name": "Основы Python", "level": 0, "max": 1, "cost": 100, "requires": [], "desc": "Фундамент для всего"},
		"cpp_hardcore": {"name": "C++ Hardcore", "level": 0, "max": 1, "cost": 5000, "requires": ["python_basics"], "desc": "Для высоконагруженных систем"}
	},
	"backend": {
		"server_admin": {"name": "Администрирование", "level": 0, "max": 5, "cost": 500, "requires": ["python_basics"], "desc": "+10% доход от серверов"},
		"cloud_arch": {"name": "Облачная архитектура", "level": 0, "max": 5, "cost": 2000, "requires": ["server_admin"], "desc": "+25% доход от серверов"}
	},
	"frontend": {
		"ui_ux_basics": {"name": "Основы UI/UX", "level": 0, "max": 1, "cost": 300, "requires": ["python_basics"], "desc": "Приложения приносят больше хайпа"},
		"reactive_apps": {"name": "Реактивные приложения", "level": 0, "max": 5, "cost": 1500, "requires": ["ui_ux_basics"], "desc": "Хайп не падает так быстро"}
	},
	"security": {
		"encryption": {"name": "Шифрование", "level": 0, "max": 5, "cost": 1000, "requires": ["python_basics"], "desc": "-10% шанс взлома"},
		"penetration": {"name": "Пентестинг", "level": 0, "max": 5, "cost": 5000, "requires": ["encryption"], "desc": "+50% доход от хакерства"}
	},
	"gamedev": {
		"game_design": {"name": "Геймдизайн", "level": 0, "max": 5, "cost": 800, "requires": ["python_basics"], "desc": "Игры приносят +20% дохода"},
		"game_engines": {"name": "Собственный движок", "level": 0, "max": 1, "cost": 15000, "requires": ["game_design", "cpp_hardcore"], "desc": "Все продукты приносят +100% дохода"}
	}
}

# --- MULTIPLIERS ---
var click_multiplier: float = 1.0
var passive_income: float = 0.0
var global_modifier: float = 1.0

func _ready():
	calculate_multipliers()
	var timer = Timer.new()
	timer.wait_time = 5.0
	timer.autostart = true
	timer.timeout.connect(_on_tick)
	add_child(timer)

func _on_tick():
	days_passed += 1
	_update_rpg()
	_update_economy()
	_update_employees()
	_update_products()
	_update_market()
	_update_marketing()
	_update_research()
	rpg_stats_changed.emit()

func _update_marketing():
	for key in active_marketing.keys():
		if active_marketing[key] > 0:
			active_marketing[key] -= 1
			# Chance to gain fans while marketing is active
			if randf() < 0.2:
				var gain = 10 * (1.0 + reputation * 0.1)
				fans += int(gain)

func _update_research():
	var rp_gain = 0.0
	for s_level in office_modules.server_slots:
		if s_level >= 2:
			rp_gain += (s_level - 1) * 0.5
	
	# Mentor boost to research: Base 1.5x + level-based bonus
	for emp in employees:
		if emp.get("is_mentor", false):
			var mentor_rp_boost = 1.5 + (emp.level * 0.1)
			rp_gain *= mentor_rp_boost
			
	research_points += rp_gain

func _update_rpg():
	energy = max(0, energy - 0.5) # Slower decay as requested
	hunger = min(100, hunger + 0.2) # Slower decay as requested
	if energy <= 0 or hunger >= 100: health = max(0, health - 2.0)
	
	if health < 50: global_modifier = 0.3
	elif energy < 20: global_modifier = 0.5
	elif energy > 80: global_modifier = 1.2
	else: global_modifier = 1.0

func restart_servers():
	servers_online = true
	calculate_multipliers()
	news_updated.emit("СЕРВЕРЫ ПЕРЕЗАГРУЖЕНЫ. Система в строю.")

func _update_economy():
	var data = STAGE_DATA[current_stage]
	rent_amount = data.rent
	var total_monthly_cost = rent_amount + data.get("living_costs", 0)
	
	# Rent and living costs every 30 ticks (representing a month)
	if days_passed % 30 == 0 and days_passed != last_rent_day:
		last_rent_day = days_passed
		if spend_money(total_monthly_cost):
			news_updated.emit("Ежемесячные расходы (%s): -%.f L-C" % [data.name, total_monthly_cost])
		else:
			health -= 15
			news_updated.emit("НЕХВАТКА СРЕДСТВ НА ЖИЗНЬ! Здоровье критически упало.")

func _update_employees():
	for emp in employees:
		if emp.get("is_on_vacation", false):
			emp.stress = max(0, emp.stress - 10)
			if emp.stress == 0: emp.is_on_vacation = false
		else:
			emp.stress = min(100, emp.stress + 1)
			if emp.stress > 80: emp.mood = max(0, emp.mood - 5)

func _update_products():
	for p in active_products:
		if randf() < 0.05: p.bugs += 1
		# Base revenue logic
		# Note: actual collection happens in ProductScene timer

func _update_market():
	for comp in competitors.keys():
		if randf() < 0.1:
			competitors[comp].market_share += 1

func add_money(amount: float):
	# Fan bonus: each fan gives a tiny boost to income
	var fan_bonus = 1.0 + (fans * 0.0001)
	var bonus = (1.0 + (reputation * 0.1)) * global_modifier * fan_bonus
	var final = amount * bonus
	
	if debt_amount > 0:
		var repayment = final * 0.5
		debt_amount -= repayment
		final -= repayment
		if debt_amount <= 0:
			debt_amount = 0
			news_updated.emit("КРЕДИТ ПОГАШЕН!")
	l_coins += final

func add_xp(amount: float):
	xp += amount * languages[current_language].xp_mult * global_modifier

func spend_money(amount: float) -> bool:
	if l_coins >= amount:
		l_coins -= amount
		return true
	return false

func fire_employee(index: int):
	if index >= 0 and index < employees.size():
		employees.remove_at(index)
		calculate_multipliers()
		return true
	return false

func start_marketing(type: String, cost: float, duration: int):
	if spend_money(cost):
		active_marketing[type] += duration
		news_updated.emit("Запущена рекламная кампания: " + type)
		calculate_multipliers()
		return true
	return false

func spend_research_points(amount: float) -> bool:
	if research_points >= amount:
		research_points -= amount
		return true
	return false

func calculate_multipliers():
	var base_click = 1.0
	match current_stage:
		Stage.APARTMENT: base_click = 1.0
		Stage.STARTUP: base_click = 10.0
		Stage.TECH_CORP: base_click = 50.0
		Stage.EMPIRE: base_click = 250.0
		Stage.BUNKER: base_click = 1000.0
	
	var lang_mult = languages[current_language].mult
	var pc_power = pc_parts.cpu.power * pc_parts.ram.power
	var tech_bonus = 1.2 if tech_tree["ai_copilot"] else 1.0
	
	click_multiplier = base_click * lang_mult * pc_power * tech_bonus * (1.0 + upgrades["keyboard"] * 0.5 + upgrades["pc"] * 1.0) * (1.2 if tech_tree["fast_typing"] else 1.0)
	
	if origin_id == "hacker": click_multiplier *= 1.5
	
	var emp_passive = 0.0
	for emp in employees:
		if not emp.get("is_on_vacation", false):
			emp_passive += emp.skill * (emp.mood / 100.0) * (1.0 - emp.stress / 200.0)
	
	var marketing_bonus = 1.0
	if active_marketing.social_media > 0: marketing_bonus += 0.2
	if active_marketing.tv > 0: marketing_bonus += 0.5
	if active_marketing.ads > 0: marketing_bonus += 0.1

	var office_bonus = (1.0 + (0.1 if office_modules.coffee_machine else 0.0)) * marketing_bonus
	var cloud_bonus = 2.0 if tech_tree["cloud_computing"] else 1.0
	
	# Apply Skill Bonuses
	var backend_skill = find_skill("server_admin")
	var backend_mult = 1.0 + (backend_skill.level * 0.1 if backend_skill else 0.0)
	var cloud_skill = find_skill("cloud_arch")
	backend_mult += (cloud_skill.level * 0.25 if cloud_skill else 0.0)

	var server_income = (upgrades["servers"] * 50.0)
	for s_level in office_modules.get("server_slots", []):
		server_income += s_level * 100.0 * cloud_bonus * backend_mult
	
	server_income += (office_modules.server_rack * 100.0 * cloud_bonus * backend_mult)
	
	var home_server_income = office_modules.home_server_tier * 25.0 * (1.0 + office_modules.home_server_tier * 0.5)
	
	# If servers are offline, income is drastically reduced
	if not servers_online:
		server_income *= 0.05
		home_server_income *= 0.1
	
	passive_income = ((upgrades["hired_coders"] * 10.0) + server_income + home_server_income + emp_passive) * office_bonus

func buy_upgrade(id: String, cost: float):
	if spend_money(cost):
		if upgrades.has(id): upgrades[id] += 1
		calculate_multipliers()
		return true
	return false

func find_skill(skill_id: String):
	for cat in skill_tree.keys():
		if skill_tree[cat].has(skill_id):
			return skill_tree[cat][skill_id]
	return null

func buy_skill(skill_id: String):
	var s = find_skill(skill_id)
	if s and s.level < s.max:
		# Check requirements
		for req in s.requires:
			var req_skill = find_skill(req)
			if req_skill == null or req_skill.level < req_skill.max:
				EventManager.emit_signal("notification_requested", "Сначала нужно изучить: " + (req_skill.name if req_skill else req))
				return false
				
		var current_cost = s.cost * (s.level + 1)
		if spend_money(current_cost):
			s.level += 1
			calculate_multipliers()
			return true
	return false

func advance_stage():
	if current_stage < Stage.BUNKER:
		current_stage = (current_stage + 1) as Stage
		calculate_multipliers()
		return true
	return false

func advance_era():
	if current_era == "Web 1.0":
		current_era = "Mobile"
		news_updated.emit("НОВАЯ ЭРА: Эпоха смартфонов началась!")
	elif current_era == "Mobile":
		current_era = "AI Era"
		news_updated.emit("НОВАЯ ЭРА: Искусственный Интеллект повсюду!")
	calculate_multipliers()

func perform_ipo():
	var earned_rep = floor(l_coins / 1000000.0)
	if earned_rep > 0:
		reputation += earned_rep
		reset_for_prestige()
		return true
	return false

func reset_for_prestige():
	l_coins = 0
	level = 1
	xp = 0
	current_stage = Stage.APARTMENT
	upgrades = {"keyboard": 0, "pc": 0, "hired_coders": 0, "servers": 0}
	employees = []
	energy = 100
	hunger = 0
	calculate_multipliers()
	stage_changed.emit(current_stage)

# --- SAVE/LOAD ---
func get_save_data() -> Dictionary:
	return {
		"player_name": player_name,
		"origin_id": origin_id,
		"intro_completed": intro_completed,
		"current_era": current_era,
		"l_coins": l_coins,
		"reputation": reputation,
		"current_stage": current_stage,
		"level": level,
		"xp": xp,
		"upgrades": upgrades,
		"tech_tree": tech_tree,
		"employees": employees,
		"active_products": active_products,
		"competitors": competitors,
		"pc_parts": pc_parts,
		"stocks": stocks,
		"office_modules": office_modules,
		"skill_tree": skill_tree,
		"alignment_score": alignment_score,
		"days_passed": days_passed
	}

func load_save_data(data: Dictionary):
	player_name = data.get("player_name", "Программист")
	origin_id = data.get("origin_id", "none")
	intro_completed = data.get("intro_completed", false)
	current_era = data.get("current_era", "Web 1.0")
	l_coins = data.get("l_coins", 0.0)
	reputation = data.get("reputation", 0.0)
	current_stage = data.get("current_stage", Stage.APARTMENT) as Stage
	level = data.get("level", 1)
	xp = data.get("xp", 0.0)
	upgrades = data.get("upgrades", upgrades)
	tech_tree = data.get("tech_tree", tech_tree)
	employees = data.get("employees", [])
	active_products = data.get("active_products", [])
	competitors = data.get("competitors", competitors)
	pc_parts = data.get("pc_parts", pc_parts)
	stocks = data.get("stocks", stocks)
	office_modules = data.get("office_modules", office_modules)
	skill_tree = data.get("skill_tree", skill_tree)
	alignment_score = data.get("alignment_score", 0)
	days_passed = data.get("days_passed", 0)
	calculate_multipliers()
