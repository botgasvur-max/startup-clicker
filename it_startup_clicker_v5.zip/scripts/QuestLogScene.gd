extends Control

@onready var quest_list = VBoxContainer.new()
@onready var hack_list = VBoxContainer.new()

func _ready():
	ThemeManager.apply_glass_theme(self)
	var main_vbox = VBoxContainer.new()
	main_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	add_child(main_vbox)
	
	var q_lbl = Label.new()
	q_lbl.text = "--- СЮЖЕТНЫЕ ЗАДАНИЯ ---"
	main_vbox.add_child(q_lbl)
	main_vbox.add_child(quest_list)
	
	var h_lbl = Label.new()
	h_lbl.text = "\n--- КОНТРАКТЫ (BLACK HAT) ---"
	main_vbox.add_child(h_lbl)
	main_vbox.add_child(hack_list)
	
	_update_ui()
	QuestManager.quests_updated.connect(_update_ui)

func _update_ui():
	for child in quest_list.get_children(): child.queue_free()
	for child in hack_list.get_children(): child.queue_free()
	
	for q in QuestManager.story_quests:
		if q.completed: continue
		var lbl = Label.new()
		lbl.text = "> %s: %s" % [q.title, q.desc]
		quest_list.add_child(lbl)
		
	for h in QuestManager.hacking_contracts:
		var hbox = HBoxContainer.new()
		var lbl = Label.new()
		lbl.text = "%s (Награда: %d L-C | Риск: %d%%)" % [h.title, h.reward, h.risk]
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hbox.add_child(lbl)
		
		var btn = Button.new()
		btn.text = "Принять"
		btn.pressed.connect(_accept_hack.bind(h.id))
		hbox.add_child(btn)
		hack_list.add_child(hbox)

func _accept_hack(id):
	QuestManager.accept_hacking(id)
	AudioManager.play_sound("open_window")
