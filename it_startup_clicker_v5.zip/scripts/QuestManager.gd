extends Node

signal quests_updated

var story_quests = [
	{
		"id": "start_revenge",
		"title": "Первая месть",
		"desc": "Заработать 1000 L-C фрилансом, чтобы купить нормальную клавиатуру.",
		"target_money": 1000,
		"completed": false,
		"next_dialogue": "mentor_revenge_1"
	},
	{
		"id": "home_server",
		"title": "Свой узел",
		"desc": "Установить первый сервер в доме для пассивного дохода.",
		"require_module": "home_server_tier",
		"target_value": 1,
		"completed": false
	}
]

var hacking_contracts = [
	{"id": "hack_wifi", "title": "Взлом Wi-Fi соседа", "reward": 200, "risk": 5, "skill_req": 0, "align_impact": -2},
	{"id": "db_leak", "title": "Слив базы данных", "reward": 1500, "risk": 20, "skill_req": 2, "align_impact": -10},
	{"id": "bank_bypass", "title": "Обход банковской защиты", "reward": 5000, "risk": 50, "skill_req": 5, "align_impact": -25},
	{"id": "crypto_drain", "title": "Опустошение криптокошелька", "reward": 3000, "risk": 35, "skill_req": 3, "align_impact": -15},
	{"id": "corporate_espionage", "title": "Корпоративный шпионаж", "reward": 8000, "risk": 60, "skill_req": 7, "align_impact": -30}
]

func _ready():
	var timer = Timer.new()
	timer.wait_time = 10.0
	timer.autostart = true
	timer.timeout.connect(_check_quests)
	add_child(timer)

func _check_quests():
	var changed = false
	for q in story_quests:
		if q.completed: continue
		
		var is_done = false
		if q.has("target_money") and GameManager.l_coins >= q.target_money:
			is_done = true
		elif q.has("require_module") and GameManager.office_modules[q.require_module] >= q.target_value:
			is_done = true
			
		if is_done:
			q.completed = true
			changed = true
			GameManager.news_updated.emit("ЗАДАНИЕ ВЫПОЛНЕНО: " + q.title)
			# Trigger dialogue logic here
	
	if changed: quests_updated.emit()

func accept_hacking(contract_id):
	var c = null
	for contract in hacking_contracts:
		if contract.id == contract_id:
			c = contract
			break
	
	if c:
		# Trigger hacking mini-game in WorkScene
		GameManager.news_updated.emit("КОНТРАКТ ПРИНЯТ: " + c.title)
		# We'll use a signal or global state to tell WorkScene to start a hack
		get_tree().root.set_meta("active_hack", c)
