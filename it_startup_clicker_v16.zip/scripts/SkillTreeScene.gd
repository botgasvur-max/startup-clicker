extends Control

@onready var skill_list = VBoxContainer.new()

func _ready():
	ThemeManager.apply_glass_theme(self)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(scroll)
	scroll.add_child(skill_list)
	_update_skills()

func _update_skills():
	for child in skill_list.get_children(): child.queue_free()
	
	# Mentor Ultimate Skills Section
	var m_title = Label.new()
	m_title.text = "--- УЛЬТИМАТИВНЫЕ НАВЫКИ CTO ---"
	m_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	m_title.modulate = Color.GOLD
	skill_list.add_child(m_title)
	
	var m_skills = GameManager.mentor_data.get("skills", {})
	for s_id in m_skills.keys():
		var m_skill = m_skills[s_id]
		var m_panel = PanelContainer.new()
		var m_hbox = HBoxContainer.new()
		m_panel.add_child(m_hbox)
		
		var m_info = Label.new()
		var is_active = m_skill.get("level", 0) > 0
		var m_status = "[АКТИВНО]" if is_active else "[ЗАБЛОКИРОВАНО]"
		m_info.text = "%s: %s\n%s" % [m_status, m_skill.get("desc", ""), "Требуется 500 Очков Исследований"]
		m_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		m_hbox.add_child(m_info)
		
		if not is_active:
			var m_buy_btn = Button.new()
			m_buy_btn.text = "Разблокировать"
			m_buy_btn.pressed.connect(_on_mentor_skill_pressed.bind(s_id))
			m_hbox.add_child(m_buy_btn)
		
		skill_list.add_child(m_panel)

	# Regular Skills
	for category in GameManager.skill_tree.keys():
		var cat_lbl = Label.new()
		cat_lbl.text = "\n--- " + category.to_upper() + " ---"
		cat_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		cat_lbl.modulate = Color.CYAN
		skill_list.add_child(cat_lbl)
		
		var skills = GameManager.skill_tree[category]
		for id in skills.keys():
			var s = skills[id]
			var s_panel = PanelContainer.new()
			var s_hbox = HBoxContainer.new()
			s_panel.add_child(s_hbox)
			
			var s_info = Label.new()
			var current_lvl = s.get("level", 0)
			var max_lvl = s.get("max", 1)
			var current_cost = s.get("cost", 100) * (current_lvl + 1)
			var reqs = s.get("requires", [])
			var req_text = ""
			if reqs.size() > 0:
				req_text = "\nТребует: " + str(reqs).replace("[", "").replace("]", "").replace('"', "")
				
			s_info.text = "%s (Ур. %d/%d)%s\n%s" % [s.get("name", id), current_lvl, max_lvl, req_text, s.get("desc", "")]
			s_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			s_hbox.add_child(s_info)
			
			if current_lvl < max_lvl:
				var buy_btn = Button.new()
				buy_btn.text = "Изучить (%d L-C)" % current_cost
				
				# Check requirements
				var can_buy = true
				for req in reqs:
					var rs = GameManager.find_skill(req)
					if rs == null or rs.get("level", 0) < rs.get("max", 0):
						can_buy = false
						break
				
				if not can_buy:
					buy_btn.disabled = true
					buy_btn.modulate = Color(0.5, 0.5, 0.5)
				
				buy_btn.pressed.connect(_on_skill_pressed.bind(id))
				s_hbox.add_child(buy_btn)
			else:
				var max_lbl = Label.new()
				max_lbl.text = "МАКСИМУМ"
				max_lbl.modulate = Color.GOLD
				s_hbox.add_child(max_lbl)
				
			skill_list.add_child(s_panel)

func _on_mentor_skill_pressed(id):
	if GameManager.spend_research_points(500):
		var m_skills = GameManager.mentor_data.get("skills", {})
		if m_skills.has(id):
			m_skills[id]["level"] = 1
		_update_skills()
		AudioManager.play_sound("upgrade")

func _on_skill_pressed(id):
	if GameManager.buy_skill(id):
		_update_skills()
		AudioManager.play_sound("upgrade")
