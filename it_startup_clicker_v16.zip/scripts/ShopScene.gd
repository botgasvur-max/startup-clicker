extends Control

@onready var items_container = %ItemsContainer
@onready var stage_progress_label = %StageProgressLabel
@onready var move_button = %MoveButton

var item_data = {
	"keyboard": {"name": "Тихая клавиатура", "cost": 50, "inc": 50, "desc": "Чтобы не будить соседей по ночам (+50% к клику)"},
	"pc": {"name": "Б/У Системник", "cost": 250, "inc": 150, "desc": "Шумит, греется, но компилирует! (+2 к силе клика)"},
	"hired_coders": {"name": "Нанять джуна", "cost": 1000, "inc": 500, "desc": "Пишет код за вас (Пассивный доход)"},
	"servers": {"name": "Аренда сервера", "cost": 5000, "inc": 2000, "desc": "Масштабирование (Большой пассивный доход)"},
	"js_unlock": {"name": "Изучить JavaScript", "cost": 3000, "inc": 0, "desc": "Открывает новый язык программирования"},
	"cpp_unlock": {"name": "Изучить C++", "cost": 15000, "inc": 0, "desc": "Открывает высокопроизводительный язык"},
}

var stage_thresholds = {
	GameManager.Stage.APARTMENT: 1500,
	GameManager.Stage.STARTUP: 15000,
	GameManager.Stage.TECH_CORP: 100000,
	GameManager.Stage.EMPIRE: 1000000,
	GameManager.Stage.BUNKER: 999999999 # Final
}

func _ready():
	ThemeManager.apply_glass_theme(self)
	_update_shop()
	GameManager.money_changed.connect(un_check_prices)

func _update_shop():
	for child in items_container.get_children():
		child.queue_free()
	
	for id in item_data.keys():
		var data = item_data[id]
		
		# Special handling for unlocks
		if id == "js_unlock" and GameManager.languages["JavaScript"]["unlocked"]: continue
		if id == "cpp_unlock" and GameManager.languages["C++"]["unlocked"]: continue
		
		var current_count = GameManager.upgrades.get(id, 0)
		var current_cost = data["cost"] + (current_count * data["inc"])
		
		var btn = Button.new()
		var count_text = " [У вас: " + str(current_count) + "]" if data["inc"] > 0 else ""
		btn.text = data["name"] + " (" + str(current_cost) + " L-C)\n" + data["desc"] + count_text
		btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		btn.pressed.connect(_on_buy_pressed.bind(id, current_cost))
		items_container.add_child(btn)
	
	_update_progression()

func un_check_prices(_amount):
	_update_progression()

func _update_progression():
	var current_stage = GameManager.current_stage
	var threshold = stage_thresholds.get(current_stage, 999999999)
	
	stage_progress_label.text = "Прогресс до переезда: " + str(floor(GameManager.l_coins)) + " / " + str(threshold)
	
	if GameManager.l_coins >= threshold and current_stage < GameManager.Stage.BUNKER:
		move_button.disabled = false
		move_button.text = "ПЕРЕЕХАТЬ / СМЕНИТЬ СТАТУС"
	else:
		move_button.disabled = true
		if current_stage == GameManager.Stage.BUNKER:
			move_button.text = "МАКСИМАЛЬНЫЙ УРОВЕНЬ ДОСТИГНУТ"
		else:
			move_button.text = "Нужно больше L-Coins"

func _on_buy_pressed(id, cost):
	if id == "js_unlock":
		if GameManager.spend_money(cost):
			GameManager.languages["JavaScript"].unlocked = true
			_update_shop()
			return
	if id == "cpp_unlock":
		if GameManager.spend_money(cost):
			GameManager.languages["C++"].unlocked = true
			_update_shop()
			return

	if GameManager.buy_upgrade(id, cost):
		_update_shop()

func _on_move_button_pressed():
	var next_stage = (GameManager.current_stage + 1) as GameManager.Stage
	var lines = []
	
	match next_stage:
		GameManager.Stage.STARTUP:
			lines = [
				{"name": GameManager.player_name, "text": "Пора расширяться. В гараже становится тесно, да и интернет постоянно падает."},
				{"name": "Система", "text": "Этап: Стартап. Теперь вы можете нанимать до 25 сотрудников."}
			]
		GameManager.Stage.TECH_CORP:
			lines = [
				{"name": GameManager.player_name, "text": "Мы выросли из коворкинга. Нам нужно свое здание."},
				{"name": "Система", "text": "Этап: Техно-Корпорация. Вместимость сотрудников и серверов значительно увеличена."}
			]
		GameManager.Stage.EMPIRE:
			lines = [
				{"name": GameManager.player_name, "text": "Пришло время показать миру, кто здесь главный."},
				{"name": "Система", "text": "Этап: Мировая Империя. Глобальное влияние."}
			]
		GameManager.Stage.BUNKER:
			lines = [
				{"name": GameManager.player_name, "text": "Мы уходим в подполье... Секретный бункер готов."},
				{"name": "Система", "text": "Этап: Секретный Бункер. Высшая точка контроля (10,000 сотрудников, 25,000 серверов)."}
			]

	if GameManager.advance_stage():
		if lines.size() > 0:
			await DialogueManager.show_dialogue(lines)
		_update_shop()
		_update_progression()
