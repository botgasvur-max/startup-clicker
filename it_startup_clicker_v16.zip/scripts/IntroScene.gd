extends Control

@onready var name_input = %NameInput
@onready var start_button = %StartButton
@onready var origin_desc = %OriginDesc
@onready var origin_selector = %OriginSelector

var origins = {
	"student": {
		"name": "Студент-должник",
		"desc": "Вы закончили вуз с долгом 5000 L-C. 50% дохода идет на погашение. БОНУС: Опыт набирается на 30% быстрее.",
		"setup": {"debt": 5000, "coins": 0, "karma": 0}
	},
	"hacker": {
		"name": "Случайный хакер",
		"desc": "Вы случайно взломали пиццерию. БОНУС: Сила клика +50%, но полиция может вами заинтересоваться.",
		"setup": {"debt": 0, "coins": 500, "karma": -10}
	},
	"garage": {
		"name": "Наследство в гараже",
		"desc": "Дед оставил вам гараж и старый компьютер. БОНУС: У вас сразу есть уникальное оборудование, но мало энергии.",
		"setup": {"debt": 0, "coins": 100, "karma": 0, "energy": 50}
	},
	"viral": {
		"name": "Виральный ролик",
		"desc": "Ваше видео стало хитом! БОНУС: Хайп сразу х2, но он быстро падает. Начните с 0 денег.",
		"setup": {"debt": 0, "coins": 0, "karma": 0, "hype": 2.0}
	}
}

var selected_origin = "student"

func _ready():
	if GameManager.intro_completed:
		get_tree().change_scene_to_file("res://scenes/Main.tscn")
		return
	
	_update_origin_info()

func _on_origin_selector_item_selected(index):
	var keys = origins.keys()
	if index >= 0 and index < keys.size():
		selected_origin = keys[index]
		_update_origin_info()

func _update_origin_info():
	var data = origins.get(selected_origin, {})
	origin_desc.text = data.get("desc", "")

func _on_start_button_pressed():
	var p_name = name_input.text.strip_edges()
	if p_name == "": p_name = "Программист"
	
	GameManager.player_name = p_name
	GameManager.origin_id = selected_origin
	
	# Apply setup
	var setup = origins.get(selected_origin, {}).get("setup", {})
	GameManager.debt_amount = float(setup.get("debt", 0))
	GameManager.l_coins = float(setup.get("coins", 0))
	GameManager.karma = int(setup.get("karma", 0))
	GameManager.energy = float(setup.get("energy", 100))
	GameManager.hype = float(setup.get("hype", 1.0))
	
	_start_intro()

func _start_intro():
	start_button.disabled = true
	var lines = [
		{"name": GameManager.player_name, "text": "Я сделал это. Бессонные ночи, тысячи строк кода... Проект для Macrosoft готов и сдан в срок."},
		{"name": "Система", "text": "Уведомление: Ваш запрос на оплату счета #404 отклонен. Причина: 'Внутренняя ошибка'. Пожалуйста, обратитесь в поддержку."},
		{"name": GameManager.player_name, "text": "Что?! Я писал им в поддержку 10 раз, но они просто закрывают тикеты! Macrosoft кинули меня на деньги..."},
		{"name": GameManager.player_name, "text": "Ладно. Если они не хотят платить честно — я заберу свое сам. И построю компанию, которая раздавит их Macrosoft."},
		{"name": GameManager.player_name, "text": "У меня остался только старый комп и этот гараж. Но этого хватит для начала мести."}
	]
	
	match selected_origin:
		"student":
			lines.append({"name": GameManager.player_name, "text": "К тому же, долг за учебу сам себя не выплатит. Придется начинать с фриланса."})
		"hacker":
			lines.append({"name": GameManager.player_name, "text": "Кстати, тот 'бесплатный заказ' пиццы принес мне 500 L-C. Буду использовать свои скрипты, чтобы работать быстрее."})
		"garage":
			lines.append({"name": GameManager.player_name, "text": "Хорошо, что дед оставил этот сервер 90-х. Старое железо еще послужит моей мести."})
		"viral":
			lines.append({"name": GameManager.player_name, "text": "А мой виральный ролик про Python поможет привлечь внимание к моему новому проекту. Пора ковать железо!"})
	
	await DialogueManager.show_dialogue(lines)
	
	# Initial Mentor Meeting
	var mentor_lines = [
		{"name": "Наставник (Ментор)", "text": "Слышал про твою ситуацию с Macrosoft. Гнилая контора, всегда такой была."},
		{"name": "Наставник (Ментор)", "text": "Я сам когда-то мечтал их свергнуть, но... перегорел. У меня есть база, знания, но нет твоей злости."},
		{"name": "Наставник (Ментор)", "text": "Если хочешь мести — я помогу. Начнем с малого. Сначала фриланс, потом — свои сервера."},
		{"name": "Наставник (Ментор)", "text": "Помни: деньги можно заработать честно, а можно... быстрее. Выбор за тобой."}
	]
	await DialogueManager.show_dialogue(mentor_lines)
	
	GameManager.intro_completed = true
	if is_inside_tree():
		get_tree().change_scene_to_file("res://scenes/Main.tscn")
